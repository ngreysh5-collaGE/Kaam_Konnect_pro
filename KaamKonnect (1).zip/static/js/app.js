/**
 * Kaam Konnect - Unified Frontend Application
 * Problem Statement ID: 26089 | Ministry of Cooperation / NCCT
 * Dedicated Login Gateway + Role-Enforced Dashboards
 */

// Global App State
const state = {
  currentUser: null,       // null when unauthenticated
  allUsers: [],
  workers: [],
  activeCategory: "All",
  searchRadius: 25,
  maxBudget: 700,
  minRating: 0,
  currentLanguage: "en",
  map: null,
  mapMarkers: []
};

// Multilingual Dictionary
const i18n = {
  en: {
    gov_banner_title: "Ministry of Cooperation, Govt. of India | National Council for Cooperative Training (NCCT)",
    tagline_sub: "Problem Statement 26089: Cooperative Gig Services Platform",
    tagline: "The Bridge to Homes",
    helpline: "1800-266-0088",
    request_callback: "Request Callback",
    tab_discovery: "Find Workers & Map",
    tab_mybookings: "My Bookings",
    tab_worker: "Worker Portal",
    tab_schemes: "Govt Welfare Schemes",
    tab_admin: "Federation Admin",
    hero_title: "Cooperative-Owned Household & Community Services",
    hero_sub: "Fair 5% worker contribution (channeled into skill training & insurance) + 5% platform fee vs 25% private commissions. Direct payments, fair wage standards, verified identities.",
    stat_commission: "Coop Tariff (vs 25%)",
    stat_direct_pay: "Direct to Worker",
    stat_ekyc: "Verified e-KYC",
    filter_title: "Filter Skilled Workers",
    filter_trade: "Service Trade",
    filter_radius: "Search Radius",
    filter_min_rating: "Minimum Rating",
    filter_budget: "Max Rate (₹ / hr)",
    map_heading: "Live Geospatial Discovery Map (Delhi NCR Region)",
    bookings_title: "Bookings & Service Receipts",
    bookings_sub: "Dual Independent Confirmation Workflow: A booking is completed ONLY when both customer confirms work done and worker confirms payment received.",
    worker_incoming_title: "Incoming Booking Requests & Active Jobs",
    schemes_title: "Government Welfare Schemes Discovery & Eligibility Engine",
    schemes_sub: "Informational gateway matching unorganized gig workers to verified Central and State welfare schemes (e-Shram, PM-SYM, PMSBY, PMJJBY, PM-JAY, BOCW Board).",
    admin_title: "Cooperative Federation Oversight & Tariff Administration",
    admin_sub: "NCCT & Labour Cooperative Federation governance: worker skill welfare fund accumulation, fair wage adherence, and dispute resolution."
  },
  hi: {
    gov_banner_title: "सहकारिता मंत्रालय, भारत सरकार | राष्ट्रीय सहकारी प्रशिक्षण परिषद (NCCT)",
    tagline_sub: "समस्या विवरण 26089: घरेलू एवं सामुदायिक सेवाओं हेतु सहकारी गिग प्लेटफॉर्म",
    tagline: "घरों तक विश्वसनीय सेतु",
    helpline: "1800-266-0088",
    request_callback: "कॉल बैक का अनुरोध करें",
    tab_discovery: "कारीगर खोजें और नक्शा",
    tab_mybookings: "मेरी बुकिंग्स",
    tab_worker: "श्रमिक पोर्टल",
    tab_schemes: "सरकारी कल्याणकारी योजनाएं",
    tab_admin: "फेडरेशन एडमिन",
    hero_title: "सहकारी स्वामित्व वाली घरेलू एवं सामुदायिक सेवाएं",
    hero_sub: "निजी कंपनियों के 25% कमीशन के बदले मात्र 5% अंशदान (कौशल विकास व बीमा हेतु) + 5% मंच शुल्क। पारदर्शी मजदूरी व सत्यापित पहचान।",
    stat_commission: "सहकारी अंशदान (बनाम 25%)",
    stat_direct_pay: "श्रमिक को सीधा भुगतान",
    stat_ekyc: "सत्यापित ई-केवाईसी",
    filter_title: "कुशल कारीगर खोजें",
    filter_trade: "कार्य क्षेत्र / ट्रेड",
    filter_radius: "खोज का दायरा",
    filter_min_rating: "न्यूनतम रेटिंग",
    filter_budget: "अधिकतम दर (₹ / घंटा)",
    map_heading: "लाइव भौगोलिक खोज नक्शा (दिल्ली एनसीआर क्षेत्र)",
    bookings_title: "बुकिंग्स एवं सेवा रसीदें",
    bookings_sub: "दोहरी स्वतंत्र पुष्टि: काम पूरा होने की पुष्टि ग्राहक द्वारा और भुगतान प्राप्ति की पुष्टि श्रमिक द्वारा होने पर ही बुकिंग पूर्ण मानी जाएगी।",
    worker_incoming_title: "आने वाले बुकिंग अनुरोध एवं सक्रिय कार्य",
    schemes_title: "सरकारी कल्याणकारी योजना खोज एवं पात्रता इंजन",
    schemes_sub: "असंगठित व गिग श्रमिकों को सत्यापित केंद्रीय व राज्य योजनाओं (ई-श्रम, पीएम-एसवाईएम, पीएमएसबीवाई, आयुष्मान भारत) से जोड़ने वाला सेतु।",
    admin_title: "सहकारी महासंघ निगरानी एवं दर प्रशासन",
    admin_sub: "एनसीटी एवं श्रम सहकारी महासंघ: 5% कल्याण निधि संग्रह, उचित मजदूरी अनुपालन और विवाद समाधान।"
  }
};

// -------------------------------------------------------------
// INITIALIZATION
// -------------------------------------------------------------
document.addEventListener("DOMContentLoaded", async () => {
  await loadDemoUsers();
  await fetchWorkers();
  
  // Default state: Show the dedicated Login Gateway
  showAuthGateway();
});

// -------------------------------------------------------------
// GATEWAY vs DASHBOARD VIEW TRANSITIONS
// -------------------------------------------------------------
function showAuthGateway() {
  document.getElementById("gateway-section").style.display = "block";
  document.getElementById("authenticated-section").style.display = "none";
  setAuthRole("customer");
  setAuthMode("signin");
}

function showAuthenticatedDashboard(user) {
  state.currentUser = user;
  document.getElementById("gateway-section").style.display = "none";
  document.getElementById("authenticated-section").style.display = "block";

  // Update header profile pill
  const avatarEl = document.getElementById("header-avatar");
  const nameEl = document.getElementById("header-user-name");
  const roleEl = document.getElementById("header-user-role");

  if (avatarEl) avatarEl.innerText = user.name.charAt(0);
  if (nameEl) nameEl.innerText = user.name;
  if (roleEl) roleEl.innerText = user.role.toUpperCase();

  // Initialize map if needed
  if (!state.map) {
    setTimeout(() => {
      initMap();
      updateMapMarkers(state.workers);
    }, 150);
  } else {
    setTimeout(() => state.map.invalidateSize(), 200);
  }

  // Route to initial role tab
  if (user.role === "worker") {
    switchTab("worker");
    loadWorkerPortal();
  } else if (user.role === "admin") {
    switchTab("admin");
    loadAdminDashboard();
  } else {
    switchTab("discovery");
    loadMyBookings();
  }
}

function signOut() {
  state.currentUser = null;
  showAuthGateway();
}

// -------------------------------------------------------------
// AUTHENTICATION CONTROLLER (Customer & Worker Portals)
// -------------------------------------------------------------
let activeAuthRole = "customer"; // 'customer' or 'worker'
let activeAuthMode = "signin";   // 'signin' or 'signup'

function setAuthRole(role) {
  activeAuthRole = role;
  document.getElementById("auth-tab-customer").classList.toggle("active", role === "customer");
  document.getElementById("auth-tab-worker").classList.toggle("active", role === "worker");

  const titleEl = document.getElementById("auth-title");
  const descEl = document.getElementById("auth-desc");
  const lblId = document.getElementById("lbl-login-id");
  const workerExtra = document.getElementById("worker-signup-extra");

  if (role === "customer") {
    if (titleEl) titleEl.innerText = "Customer Portal Sign In";
    if (descEl) descEl.innerText = "Browse verified skilled workers, book home services & confirm work";
    if (lblId) lblId.innerText = "Customer Mobile Number or Email";
    if (workerExtra) workerExtra.style.display = "none";
  } else {
    if (titleEl) titleEl.innerText = "Worker Portal Sign In";
    if (descEl) descEl.innerText = "Manage jobs, accept requests, confirm payments & access welfare schemes";
    if (lblId) lblId.innerText = "Worker Registered Mobile or Email";
    if (workerExtra) workerExtra.style.display = "block";
  }
}

function setAuthMode(mode) {
  activeAuthMode = mode;
  document.getElementById("mode-btn-signin").classList.toggle("active", mode === "signin");
  document.getElementById("mode-btn-signup").classList.toggle("active", mode === "signup");

  document.getElementById("login-form").style.display = mode === "signin" ? "block" : "none";
  document.getElementById("signup-form").style.display = mode === "signup" ? "block" : "none";
}

function simulateSendOtp() {
  const ident = document.getElementById("login-identifier").value.trim();
  if (!ident) {
    alert("Please enter your registered mobile number or email first.");
    return;
  }
  alert(`[Sandbox OTP Service]\nOne-Time Password (OTP) '882200' has been sent to ${ident}.\n(Sandbox auto-authenticates upon submitting)`);
}

async function runInlineKycCheck() {
  const aadhaarVal = document.getElementById("reg-aadhaar").value.trim();
  const nameVal = document.getElementById("reg-name").value.trim();
  const phoneVal = document.getElementById("reg-phone").value.trim();
  const statusEl = document.getElementById("reg-kyc-status");

  if (!aadhaarVal) {
    statusEl.className = "kyc-status-indicator error";
    statusEl.innerText = "Please enter 12-digit Aadhaar number.";
    return;
  }

  try {
    const res = await fetch("/api/auth/verify-kyc", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id_type: "Aadhaar",
        id_number: aadhaarVal,
        full_name: nameVal,
        phone: phoneVal
      })
    });

    const data = await res.json();
    if (data.is_verified) {
      statusEl.className = "kyc-status-indicator success";
      statusEl.innerHTML = `✓ <strong>Aadhaar Verified via Sandbox e-KYC</strong><br>Masked ID: ${data.masked_id} | Ref: ${data.kyc_ref}`;
    } else {
      statusEl.className = "kyc-status-indicator error";
      statusEl.innerText = `✗ Verification Failed: ${data.message}`;
    }
  } catch (err) {
    statusEl.className = "kyc-status-indicator error";
    statusEl.innerText = "Failed to connect to verification service.";
  }
}

async function handleLoginSubmit(e) {
  e.preventDefault();
  const identifier = document.getElementById("login-identifier").value.trim();

  try {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        identifier: identifier,
        role: activeAuthRole
      })
    });

    const data = await res.json();
    if (res.ok) {
      alert(`${data.message}\nRole: ${data.user.role.toUpperCase()} (State: ${data.user.state})`);
      showAuthenticatedDashboard(data.user);
    } else {
      alert(`${data.error}: ${data.message || data.details}`);
    }
  } catch (err) {
    alert("Network error connecting to login service.");
  }
}

async function handleRegisterSubmit(e) {
  e.preventDefault();
  const name = document.getElementById("reg-name").value.trim();
  const phone = document.getElementById("reg-phone").value.trim();
  const email = document.getElementById("reg-email").value.trim();
  const st = document.getElementById("reg-state").value;
  const address = document.getElementById("reg-address").value.trim();
  const aadhaar = document.getElementById("reg-aadhaar").value.trim();

  const payload = {
    role: activeAuthRole,
    name: name,
    phone: phone,
    email: email,
    state: st,
    city: st === "Delhi" ? "New Delhi" : (st === "Haryana" ? "Gurugram" : "Noida"),
    address: address,
    id_number: aadhaar
  };

  if (activeAuthRole === "worker") {
    payload.primary_skill = document.getElementById("reg-trade").value;
    payload.experience_years = parseInt(document.getElementById("reg-exp").value || 3);
    payload.cooperative_society_name = document.getElementById("reg-coop").value;
    payload.hourly_rate = parseFloat(document.getElementById("reg-rate").value || 380);
  }

  try {
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (res.ok) {
      alert(`Registration & KYC Verification Successful!\nWelcome, ${data.user.name}.\nMasked Aadhaar: ${data.user.kyc_id_masked}`);
      await loadDemoUsers();
      showAuthenticatedDashboard(data.user);
    } else {
      alert(`Registration Error: ${data.error}\n${data.details || ''}`);
    }
  } catch (err) {
    alert("Network error during registration.");
  }
}

function demoLogin(email, role) {
  const matched = state.allUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (matched) {
    alert(`Logged in as ${matched.name} (${matched.role.toUpperCase()})!\nState: ${matched.state} | Aadhaar: ${matched.kyc_id_masked}`);
    showAuthenticatedDashboard(matched);
  } else {
    alert("Demo user record not found.");
  }
}

async function loadDemoUsers() {
  try {
    const res = await fetch("/api/auth/users");
    state.allUsers = await res.json();
  } catch (err) {
    console.error("Failed to load demo users", err);
  }
}

// -------------------------------------------------------------
// LANGUAGE SWITCHER
// -------------------------------------------------------------
function toggleLanguage(lang) {
  state.currentLanguage = lang;
  const dict = i18n[lang] || i18n.en;
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    if (dict[key]) {
      el.innerText = dict[key];
    }
  });

  const gatewaySelect = document.getElementById("gateway-lang-select");
  const authSelect = document.getElementById("lang-select");
  if (gatewaySelect) gatewaySelect.value = lang;
  if (authSelect) authSelect.value = lang;
}

// -------------------------------------------------------------
// DASHBOARD TABS
// -------------------------------------------------------------
function switchTab(tabName) {
  document.querySelectorAll(".nav-tab-btn").forEach(btn => btn.classList.remove("active"));
  document.querySelectorAll(".tab-view").forEach(view => view.classList.remove("active"));

  const targetBtn = document.getElementById(`tab-btn-${tabName}`);
  const targetView = document.getElementById(`view-${tabName}`);

  if (targetBtn) targetBtn.classList.add("active");
  if (targetView) targetView.classList.add("active");

  if (tabName === "discovery" && state.map) {
    setTimeout(() => state.map.invalidateSize(), 200);
  } else if (tabName === "mybookings") {
    loadMyBookings();
  } else if (tabName === "worker") {
    loadWorkerPortal();
  } else if (tabName === "schemes") {
    runSchemeEvaluation();
  } else if (tabName === "admin") {
    loadAdminDashboard();
  }
}

// -------------------------------------------------------------
// GEOSPATIAL MAP (Leaflet.js + OpenStreetMap)
// -------------------------------------------------------------
function initMap() {
  const mapElement = document.getElementById("worker-map");
  if (!mapElement || state.map) return;

  const centerLat = 28.5355;
  const centerLng = 77.2185;

  state.map = L.map("worker-map").setView([centerLat, centerLng], 11);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 18,
    attribution: "© OpenStreetMap contributors | Kaam Konnect"
  }).addTo(state.map);

  const customerIcon = L.divIcon({
    className: "custom-customer-pin",
    html: `<div style="background:#c25e00; color:white; width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:14px; border:2px solid white; box-shadow:0 2px 6px rgba(0,0,0,0.3);">📍</div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 15]
  });

  L.marker([centerLat, centerLng], { icon: customerIcon })
    .addTo(state.map)
    .bindPopup("<strong>Your Location (South Delhi / Saket)</strong><br>Showing workers in nearby radius.");
}

function updateMapMarkers(workers) {
  if (!state.map) return;

  state.mapMarkers.forEach(m => state.map.removeLayer(m));
  state.mapMarkers = [];

  workers.forEach(w => {
    const isAvail = w.is_available === 1;
    const pinColor = isAvail ? "#0b6953" : "#94a3b8";

    const workerPin = L.divIcon({
      className: "custom-worker-pin",
      html: `<div style="background:${pinColor}; color:white; padding:4px 8px; border-radius:14px; font-size:11px; font-weight:700; border:2px solid white; box-shadow:0 2px 5px rgba(0,0,0,0.25); white-space:nowrap;">
               ${w.primary_skill}: ₹${w.hourly_rate}
             </div>`,
      iconSize: [80, 24],
      iconAnchor: [40, 12]
    });

    const marker = L.marker([w.latitude, w.longitude], { icon: workerPin }).addTo(state.map);

    const popupHtml = `
      <div style="font-family: var(--font-family); min-width: 180px;">
        <strong style="color: var(--coop-primary); font-size: 13px;">${w.name}</strong><br>
        <span style="font-size: 11px; color: #475569;">${w.cooperative_society_name}</span><br>
        <div style="margin: 4px 0; font-size: 12px;">
          ⭐ <strong>${w.avg_rating}</strong> (${w.rating_count} reviews) | <strong>${w.distance_km} km away</strong>
        </div>
        <div style="font-weight: 700; color: var(--coop-primary); margin-bottom: 6px;">
          Rate: ₹${w.hourly_rate}/hr
        </div>
        <button onclick="openBookingModal(${w.id})" style="background: var(--coop-primary); color: white; border: none; padding: 4px 10px; border-radius: 4px; font-size: 11px; cursor: pointer; width: 100%;">
          Book Worker
        </button>
      </div>
    `;

    marker.bindPopup(popupHtml);
    state.mapMarkers.push(marker);
  });

  const counterTag = document.getElementById("map-counter-tag");
  if (counterTag) {
    counterTag.innerText = `${workers.length} Workers Active in Radius`;
  }
}

// -------------------------------------------------------------
// WORKER DISCOVERY & FILTERS
// -------------------------------------------------------------
async function fetchWorkers() {
  const ratingVal = document.getElementById("filter-rating") ? document.getElementById("filter-rating").value : 0;
  const url = `/api/workers/discover?category=${encodeURIComponent(state.activeCategory)}&radius=${state.searchRadius}&max_price=${state.maxBudget}&min_rating=${ratingVal}&lat=28.5355&lng=77.2185`;

  try {
    const res = await fetch(url);
    const data = await res.json();
    state.workers = data.workers || [];
    renderWorkersList(state.workers);
    updateMapMarkers(state.workers);
  } catch (err) {
    console.error("Error fetching workers:", err);
  }
}

function setCategoryFilter(cat) {
  state.activeCategory = cat;
  document.querySelectorAll("#trade-chips .chip-btn").forEach(btn => {
    btn.classList.toggle("active", btn.innerText.trim() === cat);
  });
  fetchWorkers();
}

function onRadiusChanged(val) {
  state.searchRadius = val;
  document.getElementById("radius-val").innerText = `${val} km`;
  fetchWorkers();
}

function onBudgetChanged(val) {
  state.maxBudget = val;
  document.getElementById("budget-val").innerText = `₹${val}`;
  fetchWorkers();
}

function renderWorkersList(workers) {
  const container = document.getElementById("workers-list-container");
  if (!container) return;

  if (workers.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; background: white; padding: 2rem; text-align: center; border-radius: var(--radius-md); border: 1px dashed var(--coop-border);">
        <p style="color: var(--coop-text-muted); font-size: 0.95rem;">No cooperative workers found matching these filter criteria in the current radius.</p>
        <button class="btn-action-primary" onclick="setCategoryFilter('All')" style="margin-top: 10px;">Reset Filters</button>
      </div>
    `;
    return;
  }

  container.innerHTML = workers.map(w => {
    const fairBadge = w.wage_benchmark.status === "FAIR_WAGE_COMPLIANT" 
      ? `<span class="badge badge-fairwage">⚖️ Fair Wage Standard</span>`
      : `<span class="badge badge-skill">💡 Specialist Tier</span>`;

    const certBadge = w.certifications.length > 0 
      ? `<span class="badge badge-skill">📜 ${w.certifications[0].title.substring(0, 24)}...</span>` 
      : `<span class="badge badge-skill">📜 NCCT Certified</span>`;

    return `
      <div class="worker-card">
        <div>
          <div class="worker-header">
            <div class="worker-avatar">${w.name.charAt(0)}</div>
            <div class="worker-identity">
              <h3>${w.name}</h3>
              <div class="worker-coop-name">🏢 ${w.cooperative_society_name}</div>
            </div>
          </div>

          <div class="badges-row">
            <span class="badge badge-kyc">🛡️ Aadhaar Verified</span>
            ${fairBadge}
            ${certBadge}
          </div>

          <div class="worker-stats-row">
            <div>
              <div class="w-stat-val">⭐ ${w.avg_rating}</div>
              <div class="w-stat-lbl">(${w.rating_count} reviews)</div>
            </div>
            <div>
              <div class="w-stat-val">${w.jobs_completed}</div>
              <div class="w-stat-lbl">Jobs Done</div>
            </div>
            <div>
              <div class="w-stat-val">${w.distance_km} km</div>
              <div class="w-stat-lbl">Proximity</div>
            </div>
          </div>

          <p class="worker-bio">${w.bio || "Certified skilled cooperative member."}</p>
        </div>

        <div class="worker-price-footer">
          <div class="price-display">
            <span class="amount">₹${w.hourly_rate}</span>
            <span class="unit">/ hr</span>
          </div>
          <button class="btn-book" onclick="openBookingModal(${w.id})">
            Book Service
          </button>
        </div>
      </div>
    `;
  }).join("");
}

// -------------------------------------------------------------
// BOOKING CREATION & LIVE TAX QUOTE
// -------------------------------------------------------------
let activeWorkerForBooking = null;

async function openBookingModal(workerId) {
  if (!state.currentUser) {
    alert("Please sign in with your customer account to book a worker.");
    showAuthGateway();
    return;
  }

  const worker = state.workers.find(w => w.id === workerId);
  if (!worker) return;

  activeWorkerForBooking = worker;
  const modal = document.getElementById("booking-modal");
  
  document.getElementById("bm-worker-id").value = worker.id;
  document.getElementById("bm-worker-state").value = worker.state;
  document.getElementById("bm-hourly-rate").value = worker.hourly_rate;
  document.getElementById("bm-worker-info").value = `${worker.name} (${worker.primary_skill}) — ${worker.cooperative_society_name}`;
  document.getElementById("bm-service-type").value = `${worker.primary_skill} Standard Service & Maintenance`;
  
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(10, 0, 0, 0);
  document.getElementById("bm-time").value = tomorrow.toISOString().slice(0, 16);

  recalcBookingQuote();
  modal.classList.add("active");
}

async function recalcBookingQuote() {
  if (!activeWorkerForBooking) return;

  const hours = parseFloat(document.getElementById("bm-hours").value || 2);
  const rate = parseFloat(document.getElementById("bm-hourly-rate").value || 380);
  const baseAmount = hours * rate;

  const custState = state.currentUser ? state.currentUser.state : "Delhi";
  const workerState = activeWorkerForBooking.state || "Delhi";

  try {
    const res = await fetch("/api/bookings/quote", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        base_amount: baseAmount,
        customer_state: custState,
        worker_state: workerState
      })
    });
    const quote = await res.json();

    document.getElementById("quote-hours").innerText = hours;
    document.getElementById("quote-rate").innerText = rate;
    document.getElementById("quote-base").innerText = quote.base_amount.toFixed(2);
    document.getElementById("quote-tax-type").innerText = `${quote.tax_type} (${custState} → ${workerState})`;
    document.getElementById("quote-tax-desc").innerText = quote.tax_rate_description;
    document.getElementById("quote-tax-amount").innerText = quote.tax_amount.toFixed(2);
    document.getElementById("quote-fund").innerText = quote.worker_fund_contribution.toFixed(2);
    document.getElementById("quote-fee").innerText = quote.platform_fee.toFixed(2);
    document.getElementById("quote-total").innerText = quote.total_payable.toFixed(2);
  } catch (err) {
    console.error("Failed to calculate quote:", err);
  }
}

async function submitBookingForm(e) {
  e.preventDefault();
  if (!state.currentUser) {
    alert("Please sign in first.");
    return;
  }

  const workerId = parseInt(document.getElementById("bm-worker-id").value);
  const serviceType = document.getElementById("bm-service-type").value;
  const scheduledTime = document.getElementById("bm-time").value;
  const notes = document.getElementById("bm-notes").value;
  const hours = parseFloat(document.getElementById("bm-hours").value || 2);
  const rate = parseFloat(document.getElementById("bm-hourly-rate").value || 380);
  const baseAmount = hours * rate;

  try {
    const res = await fetch("/api/bookings/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customer_id: state.currentUser.id,
        worker_id: workerId,
        service_type: serviceType,
        scheduled_time: scheduledTime,
        notes: notes,
        base_amount: baseAmount
      })
    });

    const data = await res.json();
    if (res.ok) {
      closeModal("booking-modal");
      alert(`Booking ${data.booking_code} created successfully!\nStatus: Requested.\nThe cooperative worker has been notified.`);
      switchTab("mybookings");
    } else {
      alert(`Booking failed: ${data.error}`);
    }
  } catch (err) {
    alert("Network error creating booking");
  }
}

// -------------------------------------------------------------
// MY BOOKINGS & DUAL INDEPENDENT CONFIRMATION ENGINE
// -------------------------------------------------------------
async function loadMyBookings() {
  if (!state.currentUser) return;
  const container = document.getElementById("bookings-list-container");
  if (!container) return;

  const role = state.currentUser.role;
  const userId = state.currentUser.id;

  try {
    const res = await fetch(`/api/bookings/my?user_id=${userId}&role=${role}`);
    const bookings = await res.json();

    const badge = document.getElementById("bookings-badge");
    if (badge) badge.innerText = bookings.length;

    if (bookings.length === 0) {
      container.innerHTML = `
        <div style="background: white; padding: 3rem; text-align: center; border-radius: var(--radius-md); border: 1px dashed var(--coop-border);">
          <p style="color: var(--coop-text-muted); font-size: 1rem;">No bookings found for ${state.currentUser.name}.</p>
          <button class="btn-action-primary" onclick="switchTab('discovery')" style="margin-top: 12px;">Browse & Book Workers</button>
        </div>
      `;
      return;
    }

    container.innerHTML = bookings.map(b => renderBookingCard(b, role)).join("");
  } catch (err) {
    console.error("Error loading bookings:", err);
  }
}

function renderBookingCard(b, role) {
  const isCustomer = role === "customer";
  const isWorker = role === "worker";

  const workChecked = b.work_confirmed_by_customer === 1;
  const paymentChecked = b.payment_confirmed_by_worker === 1;
  const isCompleted = b.status === "Completed";

  const dualConfirmationHtml = `
    <div class="dual-confirm-box">
      <div style="font-size: 0.78rem; font-weight: 700; color: var(--coop-dark); margin-bottom: 4px;">
        🤝 Dual Independent Confirmation Status (Dispute Prevention):
      </div>
      <div class="dual-confirm-grid">
        <div class="confirm-step">
          <div class="confirm-icon ${workChecked ? 'checked' : 'pending'}">${workChecked ? '✓' : '○'}</div>
          <div>
            <strong>1. Customer Work Done Confirmation:</strong><br>
            <span style="color: ${workChecked ? 'var(--coop-success)' : 'var(--coop-warning)'};">
              ${workChecked ? 'Confirmed by Customer' : 'Pending Customer Confirmation'}
            </span>
          </div>
        </div>
        <div class="confirm-step">
          <div class="confirm-icon ${paymentChecked ? 'checked' : 'pending'}">${paymentChecked ? '✓' : '○'}</div>
          <div>
            <strong>2. Worker Payment Received Confirmation:</strong><br>
            <span style="color: ${paymentChecked ? 'var(--coop-success)' : 'var(--coop-warning)'};">
              ${paymentChecked ? 'Confirmed by Worker' : 'Pending Worker Confirmation'}
            </span>
          </div>
        </div>
      </div>
      ${(!workChecked && paymentChecked) ? '<div style="color:#b91c1c; font-size:0.75rem; margin-top:4px;">⚠️ Notice: Payment marked received, but customer has not confirmed satisfactory work.</div>' : ''}
      ${(workChecked && !paymentChecked) ? '<div style="color:#b91c1c; font-size:0.75rem; margin-top:4px;">⚠️ Notice: Customer confirmed work done, but worker payment is still pending.</div>' : ''}
    </div>
  `;

  let actionButtonsHtml = "";

  if (isCustomer) {
    if (!workChecked && (b.status === "In Progress" || b.status === "Work Completed - Pending Customer Confirmation" || b.status === "Accepted")) {
      actionButtonsHtml += `
        <button class="btn-action-success" onclick="executeBookingAction(${b.id}, 'confirm_work_customer')">
          ✓ Confirm Work Done
        </button>
      `;
    }
    if (b.status === "Requested" || b.status === "Accepted") {
      actionButtonsHtml += `
        <button class="btn-action-danger" onclick="cancelBookingPrompt(${b.id})">
          Cancel Booking
        </button>
      `;
    }
    if (isCompleted) {
      const alreadyRated = b.ratings_submitted && b.ratings_submitted.includes("customer_to_worker");
      if (!alreadyRated) {
        actionButtonsHtml += `
          <button class="btn-action-primary" onclick="openRatingModal(${b.id}, 'customer_to_worker', ${b.worker_id})">
            ⭐ Rate Worker & Service
          </button>
        `;
      } else {
        actionButtonsHtml += `<span style="font-size: 0.8rem; color: var(--coop-success); font-weight: 600;">✓ Worker Rated</span>`;
      }
    }
  }

  if (isWorker) {
    if (b.status === "Requested") {
      actionButtonsHtml += `
        <button class="btn-action-primary" onclick="executeBookingAction(${b.id}, 'accept')">Accept Request</button>
        <button class="btn-action-danger" onclick="executeBookingAction(${b.id}, 'reject')">Decline</button>
      `;
    } else if (b.status === "Accepted") {
      actionButtonsHtml += `
        <button class="btn-action-primary" onclick="executeBookingAction(${b.id}, 'start')">Start Job</button>
      `;
    } else if (b.status === "In Progress") {
      actionButtonsHtml += `
        <button class="btn-action-secondary" onclick="executeBookingAction(${b.id}, 'mark_completed')">Mark Work Completed</button>
      `;
    }

    if (!paymentChecked && (b.status === "In Progress" || b.status === "Work Completed - Pending Customer Confirmation" || workChecked)) {
      actionButtonsHtml += `
        <button class="btn-action-success" onclick="executeBookingAction(${b.id}, 'confirm_payment_worker')">
          💵 Confirm Payment Received
        </button>
      `;
    }

    if (isCompleted) {
      const alreadyRated = b.ratings_submitted && b.ratings_submitted.includes("worker_to_customer");
      if (!alreadyRated) {
        actionButtonsHtml += `
          <button class="btn-action-primary" onclick="openRatingModal(${b.id}, 'worker_to_customer', ${b.customer_id})">
            ⭐ Rate Household & Customer
          </button>
        `;
      } else {
        actionButtonsHtml += `<span style="font-size: 0.8rem; color: var(--coop-success); font-weight: 600;">✓ Household Rated</span>`;
      }
    }
  }

  return `
    <div class="booking-card">
      <div class="booking-card-header">
        <div>
          <span class="booking-code">${b.booking_code}</span>
          <span style="font-size: 0.85rem; color: #475569; margin-left: 8px;">Scheduled: <strong>${b.scheduled_time}</strong></span>
        </div>
        <div>
          <span class="status-pill status-${b.status.replace(/\s+/g, '')}">${b.status}</span>
        </div>
      </div>

      <div class="booking-parties">
        <div class="party-box">
          <div class="party-title">Customer Details (${b.customer_state})</div>
          <strong>${b.customer_name}</strong><br>
          <span>📞 ${b.customer_phone}</span><br>
          <span style="color: #64748b;">📍 ${b.customer_address}</span>
        </div>
        <div class="party-box">
          <div class="party-title">Worker Details (${b.worker_state})</div>
          <strong>${b.worker_name}</strong> (${b.primary_skill})<br>
          <span>📞 ${b.worker_phone}</span><br>
          <span style="color: #64748b;">🏢 ${b.cooperative_society_name || 'Labour Welfare Cooperative'}</span>
        </div>
      </div>

      <div style="margin: 8px 0; font-size: 0.85rem;">
        <strong>Service:</strong> ${b.service_type} <br>
        ${b.notes ? `<strong style="color: #64748b;">Notes:</strong> ${b.notes}` : ''}
      </div>

      ${dualConfirmationHtml}

      <!-- Tax & Tariff Breakdown Table -->
      <div style="background: #f8fafc; padding: 10px 14px; border-radius: var(--radius-sm); border: 1px solid var(--coop-border);">
        <div style="font-weight: 700; font-size: 0.8rem; color: var(--coop-dark); margin-bottom: 4px;">
          🧾 Invoicing & Tax Breakdown:
        </div>
        <table class="receipt-table">
          <tr>
            <td>Base Service Fee:</td>
            <td class="num">₹${b.base_amount.toFixed(2)}</td>
          </tr>
          <tr>
            <td>Applicable Tax (${b.tax_type}):</td>
            <td class="num">₹${b.tax_amount.toFixed(2)}</td>
          </tr>
          <tr style="color: #047857;">
            <td>Worker Skill & Welfare Contribution (5%):</td>
            <td class="num">₹${b.worker_fund_contribution.toFixed(2)}</td>
          </tr>
          <tr style="color: #64748b;">
            <td>Cooperative Platform Maintenance Fee (5%):</td>
            <td class="num">₹${b.platform_fee.toFixed(2)}</td>
          </tr>
          <tr class="total-row">
            <td>Final Direct Settlement Amount:</td>
            <td class="num">₹${b.total_payable.toFixed(2)}</td>
          </tr>
        </table>
      </div>

      <div class="booking-actions-row">
        ${actionButtonsHtml}
      </div>
    </div>
  `;
}

async function executeBookingAction(bookingId, action) {
  try {
    const res = await fetch(`/api/bookings/${bookingId}/action`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: action,
        user_id: state.currentUser ? state.currentUser.id : null
      })
    });

    const data = await res.json();
    if (res.ok) {
      alert(data.message);
      loadMyBookings();
      if (state.currentUser && state.currentUser.role === "worker") {
        loadWorkerPortal();
      }
      if (data.is_fully_completed) {
        alert("Booking has been Completed and Verified by both parties! Please rate your experience.");
      }
    } else {
      alert(`Action error: ${data.error}`);
    }
  } catch (err) {
    alert("Network error processing action");
  }
}

function cancelBookingPrompt(bookingId) {
  const reason = prompt("Please enter the reason for cancellation:");
  if (reason !== null) {
    executeBookingAction(bookingId, "cancel");
  }
}

// -------------------------------------------------------------
// WORKER PORTAL
// -------------------------------------------------------------
async function loadWorkerPortal() {
  if (!state.currentUser) return;
  const u = state.currentUser;

  const nameEl = document.getElementById("wp-name");
  const tradeEl = document.getElementById("wp-trade");
  const coopEl = document.getElementById("wp-coop");
  
  if (nameEl) nameEl.innerText = u.name;
  if (tradeEl) tradeEl.innerText = u.primary_skill ? `Certified ${u.primary_skill}` : "Skilled Worker";
  if (coopEl) coopEl.innerText = u.cooperative_society_name || "Delhi Labour Cooperative Federation";

  const container = document.getElementById("worker-jobs-container");
  if (!container) return;

  try {
    const res = await fetch(`/api/bookings/my?user_id=${u.id}&role=worker`);
    const jobs = await res.json();

    if (jobs.length === 0) {
      container.innerHTML = `
        <div style="background: white; padding: 2.5rem; text-align: center; border-radius: var(--radius-md); border: 1px dashed var(--coop-border);">
          <p style="color: var(--coop-text-muted);">No assigned bookings or active requests at this moment.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = jobs.map(j => renderBookingCard(j, "worker")).join("");
  } catch (err) {
    console.error("Error loading worker jobs:", err);
  }
}

// -------------------------------------------------------------
// TWO-WAY RATINGS
// -------------------------------------------------------------
function openRatingModal(bookingId, ratingType, targetUserId) {
  document.getElementById("rm-booking-id").value = bookingId;
  document.getElementById("rm-type").value = ratingType;
  document.getElementById("rm-from-id").value = state.currentUser.id;
  document.getElementById("rm-to-id").value = targetUserId;

  const isCustomerRating = ratingType === "customer_to_worker";
  document.getElementById("rm-title").innerText = isCustomerRating ? "Rate Service & Worker" : "Rate Household & Workplace Safety";
  document.getElementById("rm-lbl-safety").innerText = isCustomerRating ? "Professionalism & Safety (1-5)" : "Workplace Safety & Respect (1-5)";
  document.getElementById("rm-lbl-punctuality").innerText = isCustomerRating ? "Punctuality (1-5)" : "Prompt Payment & Courtesy (1-5)";

  setRatingScore(5);
  document.getElementById("rating-modal").classList.add("active");
}

function setRatingScore(score) {
  document.getElementById("rm-score").value = score;
  const stars = document.querySelectorAll("#star-row span");
  stars.forEach((s, idx) => {
    s.classList.toggle("selected", idx < score);
  });
}

async function submitRatingForm(e) {
  e.preventDefault();
  const bookingId = parseInt(document.getElementById("rm-booking-id").value);
  const fromUserId = parseInt(document.getElementById("rm-from-id").value);
  const toUserId = parseInt(document.getElementById("rm-to-id").value);
  const ratingType = document.getElementById("rm-type").value;
  const score = parseInt(document.getElementById("rm-score").value);
  const safety = parseInt(document.getElementById("rm-safety").value);
  const punctuality = parseInt(document.getElementById("rm-punctuality").value);
  const comments = document.getElementById("rm-comments").value;

  try {
    const res = await fetch("/api/ratings/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        booking_id: bookingId,
        from_user_id: fromUserId,
        to_user_id: toUserId,
        rating_type: ratingType,
        score: score,
        aspect_score_safety: safety,
        aspect_score_punctuality: punctuality,
        comments: comments
      })
    });

    const data = await res.json();
    if (res.ok) {
      closeModal("rating-modal");
      alert(data.message);
      loadMyBookings();
    } else {
      alert(`Rating error: ${data.error}`);
    }
  } catch (err) {
    alert("Network error submitting rating");
  }
}

// -------------------------------------------------------------
// GOVERNMENT WELFARE SCHEMES EVALUATOR
// -------------------------------------------------------------
async function runSchemeEvaluation() {
  const age = parseInt(document.getElementById("diag-age").value || 34);
  const income = parseFloat(document.getElementById("diag-income").value || 14500);
  const trade = document.getElementById("diag-trade").value;
  const st = document.getElementById("diag-state").value;
  const hasEpfo = document.getElementById("diag-epfo").value === "1";

  const container = document.getElementById("schemes-results-container");
  if (!container) return;

  try {
    const res = await fetch("/api/schemes/evaluate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        age: age,
        monthly_income: income,
        occupation: trade,
        state: st,
        has_epfo_esic: hasEpfo,
        existing_schemes: ["ESHRAM"]
      })
    });

    const data = await res.json();
    renderSchemesResults(data.schemes || []);
  } catch (err) {
    console.error("Error evaluating schemes:", err);
  }
}

function renderSchemesResults(schemes) {
  const container = document.getElementById("schemes-results-container");
  if (!container) return;

  container.innerHTML = schemes.map(s => {
    const metHtml = s.met_criteria.map(c => `<div class="criteria-item criteria-met">✓ ${c}</div>`).join("");
    const unmetHtml = s.unmet_criteria.map(c => `<div class="criteria-item criteria-unmet">✗ ${c}</div>`).join("");
    const verifyHtml = s.verify_criteria.map(c => `<div class="criteria-item criteria-verify">⚠ ${c}</div>`).join("");

    const benefitsHtml = s.benefits.map(b => `<li>${b}</li>`).join("");

    return `
      <div class="scheme-card ${s.status_tag}">
        <div class="scheme-header">
          <div class="scheme-title">
            <h3>${s.name}</h3>
            <div class="scheme-ministry">🏛️ ${s.ministry} | Category: <strong>${s.category}</strong></div>
          </div>
          <div>
            <span class="status-pill" style="background: ${s.status_tag === 'likely' ? '#dcfce7' : (s.status_tag === 'verify' ? '#fef3c7' : '#f1f5f9')}; color: ${s.status_tag === 'likely' ? '#15803d' : (s.status_tag === 'verify' ? '#b45309' : '#475569')};">
              ${s.status}
            </span>
          </div>
        </div>

        <div class="scheme-criteria-list">
          <strong>Eligibility Assessment:</strong>
          ${metHtml}
          ${unmetHtml}
          ${verifyHtml}
        </div>

        <div style="font-size: 0.82rem; margin: 8px 0;">
          <strong>Key Social Security Benefits:</strong>
          <ul style="margin-left: 18px; margin-top: 4px; color: #334155;">
            ${benefitsHtml}
          </ul>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; margin-top: 10px; border-top: 1px solid #f1f5f9; padding-top: 10px;">
          <div style="font-size: 0.82rem; color: #64748b;">
            Cost / Contribution: <strong>${s.cost}</strong>
          </div>
          <a href="${s.official_url}" target="_blank" rel="noopener noreferrer" class="btn-action-primary" style="text-decoration: none; display: inline-flex; align-items: center; gap: 4px;">
            🔗 Open ${s.portal_name} &rarr;
          </a>
        </div>

        <div class="scheme-disclaimer">
          ${s.disclaimer}
        </div>
      </div>
    `;
  }).join("");
}

// -------------------------------------------------------------
// COOPERATIVE FEDERATION ADMIN DASHBOARD
// -------------------------------------------------------------
async function loadAdminDashboard() {
  const metricsContainer = document.getElementById("admin-metrics-container");
  const disputesContainer = document.getElementById("admin-disputes-list");

  try {
    const res = await fetch("/api/admin/metrics");
    const m = await res.json();

    if (metricsContainer) {
      metricsContainer.innerHTML = `
        <div class="metric-card">
          <div class="metric-title">Cooperative Welfare Fund</div>
          <div class="metric-value">₹${m.total_welfare_fund_collected.toFixed(2)}</div>
          <div class="metric-sub">Accumulated from 5% worker contributions for certifications & insurance</div>
        </div>
        <div class="metric-card">
          <div class="metric-title">Registered Workers</div>
          <div class="metric-value">${m.total_workers}</div>
          <div class="metric-sub">${m.verified_workers} Verified via Aadhaar e-KYC (100%)</div>
        </div>
        <div class="metric-card">
          <div class="metric-title">Fair Wage Compliance</div>
          <div class="metric-value">${m.compliance_rate_percent}%</div>
          <div class="metric-sub">Adhering to NCCT urban fair wage standard</div>
        </div>
        <div class="metric-card">
          <div class="metric-title">Platform Operations Fee</div>
          <div class="metric-value">₹${m.total_platform_fee_collected.toFixed(2)}</div>
          <div class="metric-sub">Non-profit operational self-sustainability (5%)</div>
        </div>
      `;
    }

    if (m.tax_config) {
      const cfg = m.tax_config;
      document.getElementById("cfg-cgst").value = (cfg.cgst_rate * 100).toFixed(2);
      document.getElementById("cfg-sgst").value = (cfg.sgst_rate * 100).toFixed(2);
      document.getElementById("cfg-igst").value = (cfg.igst_rate * 100).toFixed(2);
      document.getElementById("cfg-worker-fund").value = (cfg.worker_contribution_rate * 100).toFixed(1);
      document.getElementById("cfg-platform-fee").value = (cfg.platform_fee_rate * 100).toFixed(1);
    }

    if (disputesContainer) {
      if (m.disputes.length === 0) {
        disputesContainer.innerHTML = `<p style="color: var(--coop-success); font-weight:600;">✓ Zero disputes. All confirmed jobs are fully aligned.</p>`;
      } else {
        disputesContainer.innerHTML = m.disputes.map(d => {
          const missing = d.work_confirmed_by_customer === 0 ? "Customer Work Confirmation Pending" : "Worker Payment Confirmation Pending";
          return `
            <div style="background: #fff1f2; border: 1px solid #fecdd3; border-radius: 4px; padding: 8px 10px; margin-bottom: 8px;">
              <strong>${d.booking_code}</strong>: ${d.service_type}<br>
              <span style="color: #64748b;">Customer: ${d.customer_name} | Worker: ${d.worker_name}</span><br>
              <span style="color: #be123c; font-weight: 700;">⚠️ ${missing}</span>
            </div>
          `;
        }).join("");
      }
    }
  } catch (err) {
    console.error("Error loading admin metrics:", err);
  }
}

async function saveTariffConfig(e) {
  e.preventDefault();
  const cgst = parseFloat(document.getElementById("cfg-cgst").value) / 100;
  const sgst = parseFloat(document.getElementById("cfg-sgst").value) / 100;
  const igst = parseFloat(document.getElementById("cfg-igst").value) / 100;
  const workerFund = parseFloat(document.getElementById("cfg-worker-fund").value) / 100;
  const platformFee = parseFloat(document.getElementById("cfg-platform-fee").value) / 100;

  try {
    const res = await fetch("/api/admin/tax-config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        cgst_rate: cgst,
        sgst_rate: sgst,
        igst_rate: igst,
        worker_contribution_rate: workerFund,
        platform_fee_rate: platformFee
      })
    });
    const data = await res.json();
    alert(data.message);
    loadAdminDashboard();
  } catch (err) {
    alert("Network error saving tariff");
  }
}

// -------------------------------------------------------------
// HELP DESK & CALLBACK MODAL
// -------------------------------------------------------------
function openCallbackModal() {
  document.getElementById("callback-modal").classList.add("active");
}

async function submitCallbackForm(e) {
  e.preventDefault();
  const name = document.getElementById("cb-name").value;
  const phone = document.getElementById("cb-phone").value;
  const category = document.getElementById("cb-category").value;
  const notes = document.getElementById("cb-notes").value;

  try {
    const res = await fetch("/api/support/callback", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: name,
        phone: phone,
        role: state.currentUser ? state.currentUser.role : activeAuthRole,
        issue_category: category,
        details: notes
      })
    });

    const data = await res.json();
    if (res.ok) {
      closeModal("callback-modal");
      alert(`${data.message}\nReference Ticket: ${data.ticket_number}\nToll-Free Helpline: ${data.support_phone}`);
    } else {
      alert(`Error: ${data.error}`);
    }
  } catch (err) {
    alert("Network error submitting callback request");
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove("active");
}

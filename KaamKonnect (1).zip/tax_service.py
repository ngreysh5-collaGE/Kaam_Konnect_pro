"""
Kaam Konnect - Configurable Tax & Commission Calculation Engine
Computes GST according to registered addresses of Customer and Worker:
- Intra-State (Same State): CGST 0.25% + SGST 0.25% = 0.50% total
- Inter-State (Different State): IGST 0.50% total
Also computes transparent cooperative breakdown:
- 5% Worker Contribution (allocated to Worker Skill & Welfare Fund)
- 5% Household Platform Fee (non-profit cooperative maintenance)
Provides Fair Wage Benchmarking comparisons against NCCT standards.
"""

from database import get_db_connection

# Official NCCT / Ministry Fair Wage Benchmarks (Hourly in INR for Delhi NCR / Tier 1 Urban)
FAIR_WAGE_BENCHMARKS = {
    "Electrician": {"min_rate": 350.0, "recommended_rate": 400.0, "max_standard": 550.0},
    "Plumber": {"min_rate": 350.0, "recommended_rate": 420.0, "max_standard": 550.0},
    "Carpenter": {"min_rate": 380.0, "recommended_rate": 450.0, "max_standard": 600.0},
    "Domestic Helper": {"min_rate": 250.0, "recommended_rate": 300.0, "max_standard": 400.0},
    "Caregiver": {"min_rate": 400.0, "recommended_rate": 500.0, "max_standard": 700.0},
    "Painter": {"min_rate": 320.0, "recommended_rate": 390.0, "max_standard": 500.0},
    "Cleaner": {"min_rate": 250.0, "recommended_rate": 320.0, "max_standard": 450.0},
    "Technician": {"min_rate": 400.0, "recommended_rate": 480.0, "max_standard": 650.0},
    "Driver": {"min_rate": 350.0, "recommended_rate": 400.0, "max_standard": 550.0},
    "Gardener": {"min_rate": 300.0, "recommended_rate": 350.0, "max_standard": 450.0}
}


def get_tax_config():
    """Fetch configurable rates from database."""
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM tax_config ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    if row:
        return {
            "cgst_rate": float(row["cgst_rate"]),
            "sgst_rate": float(row["sgst_rate"]),
            "igst_rate": float(row["igst_rate"]),
            "worker_contribution_rate": float(row["worker_contribution_rate"]),
            "platform_fee_rate": float(row["platform_fee_rate"])
        }
    # Fallback to standard defaults
    return {
        "cgst_rate": 0.0025,
        "sgst_rate": 0.0025,
        "igst_rate": 0.0050,
        "worker_contribution_rate": 0.05,
        "platform_fee_rate": 0.05
    }


def update_tax_config(cgst_rate, sgst_rate, igst_rate, worker_contrib, platform_fee):
    """Update configurable rates in database."""
    from datetime import datetime
    conn = get_db_connection()
    conn.execute("""
    INSERT INTO tax_config (name, cgst_rate, sgst_rate, igst_rate, worker_contribution_rate, platform_fee_rate, updated_at)
    VALUES ('Updated Tariff', ?, ?, ?, ?, ?, ?)
    """, (cgst_rate, sgst_rate, igst_rate, worker_contrib, platform_fee, datetime.now().isoformat()))
    conn.commit()
    conn.close()


def calculate_booking_breakdown(base_amount: float, customer_state: str, worker_state: str) -> dict:
    """
    Calculate GST, Cooperative Welfare Allocation, and total payable amount.
    Determines Intra-State vs Inter-State based on registered states.
    """
    cfg = get_tax_config()
    base = round(float(base_amount), 2)
    c_state = (customer_state or "").strip().title()
    w_state = (worker_state or "").strip().title()

    is_intra = (c_state == w_state) and bool(c_state)

    if is_intra:
        tax_type = "INTRA_STATE (CGST + SGST)"
        cgst_pct = cfg["cgst_rate"] * 100
        sgst_pct = cfg["sgst_rate"] * 100
        combined_rate = cfg["cgst_rate"] + cfg["sgst_rate"]
        
        cgst_amount = round(base * cfg["cgst_rate"], 2)
        sgst_amount = round(base * cfg["sgst_rate"], 2)
        tax_amount = round(cgst_amount + sgst_amount, 2)
        
        tax_rate_description = f"CGST @ {cgst_pct:.2f}% + SGST @ {sgst_pct:.2f}% = {combined_rate*100:.2f}%"
        tax_components = {
            "cgst_rate": cfg["cgst_rate"],
            "cgst_amount": cgst_amount,
            "sgst_rate": cfg["sgst_rate"],
            "sgst_amount": sgst_amount
        }
    else:
        tax_type = "INTER_STATE (IGST)"
        igst_pct = cfg["igst_rate"] * 100
        combined_rate = cfg["igst_rate"]
        tax_amount = round(base * cfg["igst_rate"], 2)
        tax_rate_description = f"IGST @ {igst_pct:.2f}%"
        tax_components = {
            "igst_rate": cfg["igst_rate"],
            "igst_amount": tax_amount
        }

    # Cooperative Welfare & Skill Fund (5% Worker contribution)
    worker_fund = round(base * cfg["worker_contribution_rate"], 2)
    
    # Non-Profit Platform Operations Fee (5% Household contribution)
    platform_fee = round(base * cfg["platform_fee_rate"], 2)

    # In our cooperative model:
    # Customer pays base amount + tax directly to worker (or cooperative settlement gateway)
    # Total payable by household: base + tax + platform_fee
    total_payable = round(base + tax_amount, 2)
    net_worker_takehome = round(base - worker_fund, 2)

    return {
        "base_amount": base,
        "customer_state": c_state,
        "worker_state": w_state,
        "is_intra_state": is_intra,
        "tax_type": tax_type,
        "tax_rate": combined_rate,
        "tax_rate_percentage": round(combined_rate * 100, 2),
        "tax_rate_description": tax_rate_description,
        "tax_amount": tax_amount,
        "tax_components": tax_components,
        "worker_fund_contribution": worker_fund,
        "worker_fund_percentage": round(cfg["worker_contribution_rate"] * 100, 1),
        "platform_fee": platform_fee,
        "platform_fee_percentage": round(cfg["platform_fee_rate"] * 100, 1),
        "total_payable": total_payable,
        "net_worker_takehome": net_worker_takehome,
        "cooperative_advantage": {
            "private_commission_rate": "25% - 30%",
            "kaam_konnect_rate": "5% (reinvested in worker skill certifications & insurance)",
            "worker_savings": round(base * 0.20, 2)
        }
    }


def evaluate_wage_benchmark(skill: str, rate: float) -> dict:
    """Evaluate whether an hourly or base quote adheres to Fair Wage Standards."""
    benchmark = FAIR_WAGE_BENCHMARKS.get(skill, {"min_rate": 300.0, "recommended_rate": 400.0, "max_standard": 600.0})
    rate = float(rate)
    
    if rate < benchmark["min_rate"]:
        status = "BELOW_BENCHMARK"
        message = f"Rate is below recommended NCCT fair wage (₹{benchmark['min_rate']}/hr)."
        badge_class = "warning"
    elif rate <= benchmark["max_standard"]:
        status = "FAIR_WAGE_COMPLIANT"
        message = f"Fair Wage Compliant (NCCT Benchmark: ₹{benchmark['min_rate']} - ₹{benchmark['max_standard']}/hr)."
        badge_class = "success"
    else:
        status = "PREMIUM_SPECIALIST"
        message = f"Premium Tier (Standard benchmark is ₹{benchmark['recommended_rate']}/hr)."
        badge_class = "info"

    return {
        "status": status,
        "message": message,
        "badge_class": badge_class,
        "benchmark": benchmark
    }

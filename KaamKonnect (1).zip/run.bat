@echo off
title Kaam Konnect - The Bridge to Homes (Ministry of Cooperation)
echo ================================================================
echo   KAAM KONNECT - COOPERATIVE GIG SERVICES PLATFORM
echo   Problem Statement ID: 26089 | Ministry of Cooperation / NCCT
echo ================================================================
echo.
echo Initializing Database and Checking Dependencies...
python database.py
echo.
echo Starting Web Server on http://127.0.0.1:5000 ...
echo Press CTRL+C to stop the server.
echo.
python app.py
pause

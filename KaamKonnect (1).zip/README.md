# Kaam Konnect (काम कनेक्ट)
*The Bridge to Homes*

**Problem Statement ID**: 26089  
**Problem Statement Title**: Cooperative Gig Services Platform for Household & Community Services  
**Organization**: Ministry of Cooperation | National Council for Cooperative Training (NCCT)  
**Theme**: Agriculture, FoodTech & Rural Development / Cooperative & Gig Economy  

---

## 🌟 Solution Overview & Cooperative Differentiation

Kaam Konnect is a cooperative-owned digital service marketplace that empowers Labour Cooperative Federations and Societies to connect verified, skilled workers (electricians, plumbers, carpenters, domestic helpers, caregivers, painters, cleaners, technicians, drivers, gardeners) with households and community institutions.

### Key Differentiators:
1. **Lower Commission (5% + 5% vs 25% Private Giants)**:  
   Private platforms extract ~25% commission from worker earnings. Kaam Konnect collects only a **5% contribution from the worker** and **5% from the household**.
2. **Skill Fund Reinvestment**:  
   The worker's 5% contribution is channeled into **portable skill certifications (NCCT / NSDC), social security, and group insurance**.
3. **We Do Not Employ the Workers**:  
   We act as a gateway connecting workers with households. The customer **pays the worker directly** (via Cash / UPI / Cooperative QR).
4. **Fair Wage Benchmarking**:  
   Rule-based benchmarking compares rates against official NCCT/Ministry standards for each trade and metropolitan tier.
5. **Dual Independent Confirmation**:  
   A booking transitions to `Completed` **only** after both:
   - Customer triggers **"Confirm Work Done"**
   - Worker triggers **"Confirm Payment Received"**  
   Disputes (work done but unpaid, or paid but work unconfirmed) are clearly surfaced.
6. **Pluggable Government e-KYC**:  
   Aadhaar-style 12-digit format verification with Verhoeff algorithmic check and modular architecture to swap in licensed UIDAI/DigiLocker providers.
7. **Verified Government Schemes Module**:  
   Matches unorganized workers against real statutory schemes (**e-Shram, PM-SYM, PMJJBY, PMSBY, PM-JAY, BOCW Boards**) with direct links to official portals (`eshram.gov.in`, `maandhan.in`, `pmjay.gov.in`).
8. **Geospatial Discovery**:  
   Interactive Leaflet & OpenStreetMap view mapping verified workers across Delhi NCR (South Delhi, Gurgaon, Noida, Dwarka).

---

## 🏗️ Architecture & Tax Configuration

### Configurable GST Engine (Stored in SQLite `tax_config` table):
- **Intra-State (Customer State == Worker State)**:  
  `CGST (0.25%) + SGST (0.25%) = 0.50% total GST`
- **Inter-State (Customer State != Worker State)**:  
  `IGST = 0.50% total GST`

### Pre-Seeded Demonstration Personas:
- **Priya Sharma (Customer - Delhi)**: Books Delhi workers under **Intra-State GST**.
- **Anand Verma (Customer - Haryana)**: Books Delhi workers under **Inter-State IGST**.
- **Ramesh Kumar (Worker - Electrician, Delhi)**: 9 yrs experience, NCCT Level 4 certified, 4.9 rating.
- **Sunita Devi (Worker - Domestic Helper, Delhi)**: 7 yrs experience, e-Shram registered, 4.8 rating.
- **Shri S. K. Awasthi (Admin - NCCT Federation)**: Oversees welfare fund pool, fair wage compliance, and dispute queues.

---

## 🚀 Running the Platform

### 1. Requirements:
- Python 3.10+
- Flask (`pip install flask`)

### 2. Initialize Database and Seed Data:
```bash
python database.py
```

### 3. Run Automated Tests:
```bash
python test_platform.py
```
*(Runs 8 tests validating KYC, geospatial search, tax math, dual-confirmation lifecycle, ratings, and schemes matching)*

### 4. Start the Application:
```bash
python app.py
```
Open your browser at: **`http://localhost:5000`**

---

## 🏛️ Ministry & Statutory Compliance Note
All government scheme eligibility evaluations are informational. Kaam Konnect does not collect government scheme fees or fabricate live API calls. Final statutory enrollment must be conducted directly on respective government portals.

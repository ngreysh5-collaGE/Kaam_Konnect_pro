"""
Kaam Konnect - Government Welfare Schemes Matching Engine
Matches unorganized and gig workers with verified, real Central and State welfare schemes:
- e-Shram (NDUW)
- Pradhan Mantri Shram Yogi Maan-dhan (PM-SYM)
- Pradhan Mantri Suraksha Bima Yojana (PMSBY)
- Pradhan Mantri Jeevan Jyoti Bima Yojana (PMJJBY)
- Ayushman Bharat - PM-JAY
- State BOCW Welfare Board Schemes

Hard constraints honored:
1. Strict adherence to publicly documented statutory criteria.
2. Direct links to official government portals (no fake in-app enrollment).
3. Clear legal disclaimers on every recommendation.
"""

import json
from database import get_db_connection

STATUTORY_SCHEMES = [
    {
        "code": "ESHRAM",
        "name": "e-Shram: National Database of Unorganized Workers",
        "ministry": "Ministry of Labour & Employment, Govt. of India",
        "category": "Identity & Social Security Portability",
        "min_age": 16,
        "max_age": 59,
        "max_income": 25000,
        "requires_non_epfo": True,
        "occupations": ["Electrician", "Plumber", "Carpenter", "Domestic Helper", "Caregiver", "Painter", "Cleaner", "Driver", "Gardener", "Technician", "All Unorganized"],
        "benefits": [
            "12-digit Universal Account Number (UAN) with national portability",
            "Accidental Insurance cover of ₹2,00,000 for death/permanent disability under PMSBY",
            "Direct Benefit Transfer (DBT) eligibility during disaster/emergency reliefs",
            "Seamless integration with PM-SYM, PMSBY, and state welfare boards"
        ],
        "cost": "100% Free of Cost Registration",
        "official_url": "https://eshram.gov.in",
        "portal_name": "Official e-Shram Self-Enrollment Portal"
    },
    {
        "code": "PMSYM",
        "name": "Pradhan Mantri Shram Yogi Maan-dhan (PM-SYM)",
        "ministry": "Ministry of Labour & Employment, Govt. of India",
        "category": "Old Age Pension Security",
        "min_age": 18,
        "max_age": 40,
        "max_income": 15000,
        "requires_non_epfo": True,
        "occupations": ["Domestic Helper", "Gardener", "Cleaner", "Painter", "Carpenter", "Plumber", "Electrician", "Driver"],
        "benefits": [
            "Assured minimum monthly pension of ₹3,000 after reaching age 60",
            "50% Monthly contribution matched equally by the Central Government",
            "50% Family pension for spouse in case of beneficiary demise during pension period"
        ],
        "cost": "₹55 to ₹200/month (matching equal contribution by Central Govt)",
        "official_url": "https://maandhan.in",
        "portal_name": "Official Maandhan Pension Portal"
    },
    {
        "code": "PMSBY",
        "name": "Pradhan Mantri Suraksha Bima Yojana (PMSBY)",
        "ministry": "Department of Financial Services, Ministry of Finance",
        "category": "Accident Insurance",
        "min_age": 18,
        "max_age": 70,
        "max_income": None,
        "requires_non_epfo": False,
        "occupations": ["All"],
        "benefits": [
            "₹2,00,000 cover for accidental death and full permanent disability",
            "₹1,00,000 cover for partial permanent disability",
            "Direct claim settlement into linked savings bank account"
        ],
        "cost": "₹20 per year (auto-debited from bank account)",
        "official_url": "https://financialservices.gov.in",
        "portal_name": "Financial Services Official Portal / Any Bank"
    },
    {
        "code": "PMJJBY",
        "name": "Pradhan Mantri Jeevan Jyoti Bima Yojana (PMJJBY)",
        "ministry": "Department of Financial Services, Ministry of Finance",
        "category": "Life Insurance",
        "min_age": 18,
        "max_age": 50,
        "max_income": None,
        "requires_non_epfo": False,
        "occupations": ["All"],
        "benefits": [
            "₹2,00,000 renewable life insurance cover in case of death due to any reason",
            "Protection for dependent family members of gig workers"
        ],
        "cost": "₹436 per year (auto-debited from bank account)",
        "official_url": "https://financialservices.gov.in",
        "portal_name": "Financial Services Portal / Scheduled Banks"
    },
    {
        "code": "PMJAY",
        "name": "Ayushman Bharat - Pradhan Mantri Jan Arogya Yojana (PM-JAY)",
        "ministry": "National Health Authority / MoHFW",
        "category": "Health Insurance Cover",
        "min_age": 18,
        "max_age": 75,
        "max_income": 20000,
        "requires_non_epfo": True,
        "occupations": ["Domestic Helper", "Cleaner", "Gardener", "Painter", "Plumber", "Carpenter", "Driver"],
        "benefits": [
            "Cashless hospitalization coverage up to ₹5,00,000 per family per year",
            "Covers secondary and tertiary care at 27,000+ empaneled public and private hospitals",
            "Zero out-of-pocket cost for diagnostic tests, pre- and post-hospitalization medicines"
        ],
        "cost": "100% Fully funded by Government (Zero premium)",
        "official_url": "https://pmjay.gov.in",
        "portal_name": "Ayushman Bharat Official Portal"
    },
    {
        "code": "BOCW_BOARD",
        "name": "State Building & Other Construction Workers (BOCW) Welfare Schemes",
        "ministry": "State Labour Welfare Boards (Delhi, Haryana, UP, etc.)",
        "category": "State Worker Welfare Board",
        "min_age": 18,
        "max_age": 60,
        "max_income": 30000,
        "requires_non_epfo": True,
        "occupations": ["Electrician", "Plumber", "Carpenter", "Painter", "Technician"],
        "benefits": [
            "Free professional toolkit grant or subsidy up to ₹10,000",
            "Children education financial assistance from class 1 through higher degrees",
            "Maternity financial assistance up to ₹30,000 for women workers / spouse",
            "Disability and funeral grant assistance"
        ],
        "cost": "Nominal annual registration ₹20 - ₹50 at State Board",
        "official_url": "https://labour.gov.in",
        "portal_name": "Ministry of Labour / State BOCW Boards"
    }
]


def evaluate_worker_eligibility(worker_data: dict) -> list:
    """
    Evaluate worker against statutory schemes.
    Input worker_data:
      - age (int)
      - monthly_income (float)
      - occupation (str)
      - state (str)
      - has_epfo_esic (bool)
      - existing_schemes (list of codes)
    """
    age = int(worker_data.get("age", 30))
    income = float(worker_data.get("monthly_income", 15000.0))
    occupation = (worker_data.get("occupation") or "").strip()
    state = (worker_data.get("state") or "").strip()
    has_epfo = bool(worker_data.get("has_epfo_esic", False))
    existing_schemes = worker_data.get("existing_schemes", [])
    if isinstance(existing_schemes, str):
        try:
            existing_schemes = json.loads(existing_schemes)
        except Exception:
            existing_schemes = [existing_schemes]

    results = []

    for scheme in STATUTORY_SCHEMES:
        code = scheme["code"]
        already_registered = code in existing_schemes

        met_criteria = []
        unmet_criteria = []
        verify_criteria = []

        # Age Check
        if scheme["min_age"] <= age <= scheme["max_age"]:
            met_criteria.append(f"Age {age} falls within eligible bracket ({scheme['min_age']} - {scheme['max_age']} years)")
        else:
            unmet_criteria.append(f"Age {age} outside statutory range ({scheme['min_age']} - {scheme['max_age']} years)")

        # EPFO / ESIC check (for unorganized worker schemes)
        if scheme["requires_non_epfo"]:
            if not has_epfo:
                met_criteria.append("Unorganized worker (Not enrolled in formal EPFO/ESIC)")
            else:
                unmet_criteria.append("Formal sector member (Active EPFO/ESIC members excluded from unorganized welfare schemes)")

        # Income Check
        if scheme["max_income"] is not None:
            if income <= scheme["max_income"]:
                met_criteria.append(f"Monthly income ₹{income:,.0f} is within limit (Max ₹{scheme['max_income']:,.0f})")
            else:
                unmet_criteria.append(f"Monthly income ₹{income:,.0f} exceeds scheme ceiling (Max ₹{scheme['max_income']:,.0f})")

        # Occupation Check
        if "All" in scheme["occupations"] or "All Unorganized" in scheme["occupations"]:
            met_criteria.append(f"Occupation '{occupation}' recognized under general unorganized gig sector")
        elif occupation in scheme["occupations"]:
            met_criteria.append(f"Trade '{occupation}' is directly listed as a beneficiary sector")
        else:
            verify_criteria.append(f"Trade '{occupation}' may require specific sub-category verification under {scheme['category']}")

        # Status determination
        if already_registered:
            status = "Already Enrolled"
            status_tag = "enrolled"
            badge_color = "success"
        elif len(unmet_criteria) == 0 and len(verify_criteria) == 0:
            status = "Likely Eligible"
            status_tag = "likely"
            badge_color = "primary"
        elif len(unmet_criteria) == 0 and len(verify_criteria) > 0:
            status = "Possibly Eligible – Verify"
            status_tag = "verify"
            badge_color = "warning"
        else:
            status = "Not Eligible"
            status_tag = "not_eligible"
            badge_color = "secondary"

        results.append({
            "code": code,
            "name": scheme["name"],
            "ministry": scheme["ministry"],
            "category": scheme["category"],
            "status": status,
            "status_tag": status_tag,
            "badge_color": badge_color,
            "already_registered": already_registered,
            "met_criteria": met_criteria,
            "unmet_criteria": unmet_criteria,
            "verify_criteria": verify_criteria,
            "benefits": scheme["benefits"],
            "cost": scheme["cost"],
            "official_url": scheme["official_url"],
            "portal_name": scheme["portal_name"],
            "disclaimer": (
                "Statutory Disclaimer: Kaam Konnect is an informational discovery bridge under the "
                "Cooperative Gig Framework. This platform never collects government scheme fees or simulates "
                "unauthorized API submissions. Final entitlement and documentation verification must be performed "
                "directly on the official Government portal."
            )
        })

    return results

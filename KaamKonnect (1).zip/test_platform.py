"""
Kaam Konnect - Automated Test Suite
Validates:
1. User registration & pluggable Aadhaar KYC validation
2. Geospatial worker discovery & ranking
3. Tax engine: Intra-State (CGST+SGST 0.5%) vs Inter-State (IGST 0.5%)
4. Booking lifecycle with Dual Independent Confirmation (Dispute prevention)
5. Two-way rating system
6. Real Government Welfare Schemes matching engine
7. Cooperative federation admin metrics
"""

import sys
import json
import unittest
from datetime import datetime, timedelta

from app import app
from database import init_db, seed_data, get_db_connection
from scheme_engine import STATUTORY_SCHEMES


class KaamKonnectTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        init_db()
        seed_data(force=True)
        cls.client = app.test_client()

    def test_00_index_page_and_branding(self):
        """Verify homepage renders with proper cooperative branding & tagline."""
        res = self.client.get("/")
        self.assertEqual(res.status_code, 200)
        html = res.get_data(as_text=True)
        self.assertIn("Kaam Konnect", html)
        self.assertIn("The Bridge to Homes", html)
        self.assertIn("worker-map", html)
        self.assertIn("1800-266-0088", html)

    def test_01_demo_users_exist(self):
        """Ensure demo users are seeded with verified KYC."""
        res = self.client.get("/api/auth/users")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertGreaterEqual(len(data), 10)
        # Check that we have customers, workers, and admin
        roles = {u["role"] for u in data}
        self.assertIn("customer", roles)
        self.assertIn("worker", roles)
        self.assertIn("admin", roles)

    def test_01b_login_endpoints_and_role_protection(self):
        """Test Customer & Worker login flows and role protection."""
        # 1. Successful Customer Login
        res_c = self.client.post("/api/auth/login", json={
            "identifier": "priya.sharma@example.com",
            "role": "customer"
        })
        self.assertEqual(res_c.status_code, 200)
        self.assertEqual(res_c.get_json()["user"]["role"], "customer")

        # 2. Successful Worker Login
        res_w = self.client.post("/api/auth/login", json={
            "identifier": "ramesh.electrician@coop.in",
            "role": "worker"
        })
        self.assertEqual(res_w.status_code, 200)
        self.assertEqual(res_w.get_json()["user"]["primary_skill"], "Electrician")

        # 3. Role mismatch protection (Worker credentials on Customer portal)
        res_mismatch = self.client.post("/api/auth/login", json={
            "identifier": "ramesh.electrician@coop.in",
            "role": "customer"
        })
        self.assertEqual(res_mismatch.status_code, 403)

    def test_02_pluggable_kyc_verification(self):
        """Test Aadhaar format and Verhoeff sandbox check."""
        # Valid test Aadhaar (12 digits)
        res = self.client.post("/api/auth/verify-kyc", json={
            "id_type": "Aadhaar",
            "id_number": "992144558899",
            "full_name": "Test Citizen",
            "phone": "+919811223399"
        })
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data["is_verified"])
        self.assertEqual(data["provider"], "SANDBOX_MOCK_EKYC")
        self.assertEqual(data["masked_id"], "XXXX-XXXX-8899")

        # Invalid format test
        res_bad = self.client.post("/api/auth/verify-kyc", json={
            "id_type": "Aadhaar",
            "id_number": "123", # Too short
            "full_name": "Bad Citizen",
            "phone": "+919811223399"
        })
        self.assertFalse(res_bad.get_json()["is_verified"])

    def test_03_geospatial_worker_discovery(self):
        """Test finding workers by category, distance, and rating."""
        # Search Electricians around South Delhi (Saket: 28.5355, 77.2185) within 20km
        res = self.client.get("/api/workers/discover?category=Electrician&lat=28.5355&lng=77.2185&radius=20")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertGreaterEqual(data["total_matched"], 1)
        worker = data["workers"][0]
        self.assertEqual(worker["primary_skill"], "Electrician")
        self.assertIn("distance_km", worker)
        self.assertIn("wage_benchmark", worker)
        self.assertIn("match_score", worker)

    def test_04_tax_calculation_intra_vs_inter_state(self):
        """
        Verify GST logic:
        - Delhi to Delhi: Intra-State (CGST 0.25% + SGST 0.25% = 0.50%)
        - Haryana to Delhi: Inter-State (IGST 0.50%)
        """
        # Case A: Intra-State (Both in Delhi)
        res_intra = self.client.post("/api/bookings/quote", json={
            "base_amount": 1000.0,
            "customer_state": "Delhi",
            "worker_state": "Delhi"
        })
        self.assertEqual(res_intra.status_code, 200)
        intra_data = res_intra.get_json()
        self.assertTrue(intra_data["is_intra_state"])
        self.assertIn("CGST + SGST", intra_data["tax_type"])
        self.assertEqual(intra_data["tax_amount"], 5.0) # 1000 * 0.005
        self.assertEqual(intra_data["worker_fund_contribution"], 50.0) # 5% worker skill fund
        self.assertEqual(intra_data["total_payable"], 1005.0)

        # Case B: Inter-State (Customer Haryana, Worker Delhi)
        res_inter = self.client.post("/api/bookings/quote", json={
            "base_amount": 1000.0,
            "customer_state": "Haryana",
            "worker_state": "Delhi"
        })
        self.assertEqual(res_inter.status_code, 200)
        inter_data = res_inter.get_json()
        self.assertFalse(inter_data["is_intra_state"])
        self.assertIn("IGST", inter_data["tax_type"])
        self.assertEqual(inter_data["tax_amount"], 5.0) # 1000 * 0.005
        self.assertEqual(inter_data["total_payable"], 1005.0)

    def test_05_booking_lifecycle_and_dual_independent_confirmation(self):
        """
        Critical workflow:
        1. Customer creates booking (state -> Requested)
        2. Worker accepts (state -> Accepted)
        3. Worker starts (state -> In Progress)
        4. Worker marks done (state -> Work Completed - Pending Customer Confirmation)
        5. Customer confirms work done (work_confirmed = 1, but payment not confirmed yet -> still pending)
        6. Worker confirms payment received (payment_confirmed = 1 -> BOTH confirmed -> state transitions to Completed)
        7. Two-way rating unlocked
        """
        # Fetch a customer and worker
        conn = get_db_connection()
        customer = conn.execute("SELECT id, state FROM users WHERE role = 'customer' LIMIT 1").fetchone()
        worker = conn.execute("SELECT id, user_id FROM workers LIMIT 1").fetchone()
        conn.close()

        # Step 1: Create booking
        create_res = self.client.post("/api/bookings/create", json={
            "customer_id": customer["id"],
            "worker_id": worker["id"],
            "service_type": "Plumbing Diagnostic & Pipe Fitting",
            "scheduled_time": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d 11:00"),
            "notes": "Bathroom mixer tap leakage.",
            "base_amount": 500.0
        })
        self.assertEqual(create_res.status_code, 201)
        b_data = create_res.get_json()
        booking_id = b_data["booking_id"]
        self.assertEqual(b_data["status"], "Requested")

        # Step 2: Worker accepts
        act_res = self.client.post(f"/api/bookings/{booking_id}/action", json={"action": "accept"})
        self.assertEqual(act_res.status_code, 200)
        self.assertEqual(act_res.get_json()["status"], "Accepted")

        # Step 3: Worker starts
        act_res = self.client.post(f"/api/bookings/{booking_id}/action", json={"action": "start"})
        self.assertEqual(act_res.status_code, 200)
        self.assertEqual(act_res.get_json()["status"], "In Progress")

        # Step 4: Worker marks completed
        act_res = self.client.post(f"/api/bookings/{booking_id}/action", json={"action": "mark_completed"})
        self.assertEqual(act_res.status_code, 200)
        self.assertEqual(act_res.get_json()["status"], "Work Completed - Pending Customer Confirmation")

        # Step 5: Customer confirms work done
        act_res = self.client.post(f"/api/bookings/{booking_id}/action", json={"action": "confirm_work_customer"})
        self.assertEqual(act_res.status_code, 200)
        res_data = act_res.get_json()
        self.assertEqual(res_data["work_confirmed_by_customer"], 1)
        self.assertEqual(res_data["payment_confirmed_by_worker"], 0)
        # Crucial check: must NOT be Completed yet because payment confirmation is pending!
        self.assertFalse(res_data["is_fully_completed"])

        # Step 6: Worker confirms payment received
        act_res = self.client.post(f"/api/bookings/{booking_id}/action", json={"action": "confirm_payment_worker"})
        self.assertEqual(act_res.status_code, 200)
        res_data = act_res.get_json()
        self.assertEqual(res_data["work_confirmed_by_customer"], 1)
        self.assertEqual(res_data["payment_confirmed_by_worker"], 1)
        # Now BOTH confirmations are satisfied -> status is Completed!
        self.assertTrue(res_data["is_fully_completed"])
        self.assertEqual(res_data["status"], "Completed")

        # Step 7: Submit Two-Way Ratings
        # 7a: Customer rates worker
        c_rate = self.client.post("/api/ratings/submit", json={
            "booking_id": booking_id,
            "from_user_id": customer["id"],
            "to_user_id": worker["user_id"],
            "rating_type": "customer_to_worker",
            "score": 5,
            "aspect_score_safety": 5,
            "aspect_score_punctuality": 5,
            "comments": "Fixed pipe leakage with great precision and polite conduct."
        })
        self.assertEqual(c_rate.status_code, 200)

        # 7b: Worker rates customer
        w_rate = self.client.post("/api/ratings/submit", json={
            "booking_id": booking_id,
            "from_user_id": worker["user_id"],
            "to_user_id": customer["id"],
            "rating_type": "worker_to_customer",
            "score": 5,
            "aspect_score_safety": 5,
            "aspect_score_punctuality": 5,
            "comments": "Very welcoming household, offered water, paid promptly."
        })
        self.assertEqual(w_rate.status_code, 200)

    def test_06_government_schemes_evaluation(self):
        """Test worker eligibility against real statutory welfare schemes."""
        worker_profile = {
            "age": 32,
            "monthly_income": 12000.0,
            "occupation": "Electrician",
            "state": "Delhi",
            "has_epfo_esic": False,
            "existing_schemes": ["ESHRAM"]
        }
        res = self.client.post("/api/schemes/evaluate", json=worker_profile)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data["total_schemes"], len(STATUTORY_SCHEMES))
        
        schemes_by_code = {s["code"]: s for s in data["schemes"]}
        
        # e-Shram should be marked as Already Enrolled
        self.assertEqual(schemes_by_code["ESHRAM"]["status"], "Already Enrolled")
        
        # PM-SYM (income 12000 <= 15000, age 32 in 18-40) should be Likely Eligible
        self.assertEqual(schemes_by_code["PMSYM"]["status"], "Likely Eligible")
        self.assertIn("https://maandhan.in", schemes_by_code["PMSYM"]["official_url"])

        # BOCW Board (Electrician in 18-60) should be Likely Eligible
        self.assertEqual(schemes_by_code["BOCW_BOARD"]["status"], "Likely Eligible")

    def test_07_cooperative_federation_admin_metrics(self):
        """Test admin metrics including welfare fund pool and dispute tracking."""
        res = self.client.get("/api/admin/metrics")
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn("total_workers", data)
        self.assertIn("total_welfare_fund_collected", data)
        self.assertIn("compliance_rate_percent", data)
        self.assertIn("disputes_count", data)
        self.assertIn("tax_config", data)


if __name__ == "__main__":
    unittest.main()

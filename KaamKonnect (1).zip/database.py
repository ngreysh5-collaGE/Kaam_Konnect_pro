"""
Kaam Konnect - Database Engine & Seed Module
Cooperative Gig Services Platform for Household & Community Services
Ministry of Cooperation | National Council for Cooperative Training (NCCT)
"""

import sqlite3
import os
import json
from datetime import datetime, timedelta

DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "kaam_konnect.db")


def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Users Table (Customer, Worker, Admin)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role TEXT NOT NULL CHECK(role IN ('customer', 'worker', 'admin')),
        name TEXT NOT NULL,
        phone TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        state TEXT NOT NULL,
        city TEXT NOT NULL,
        address TEXT NOT NULL,
        kyc_status TEXT NOT NULL DEFAULT 'verified' CHECK(kyc_status IN ('unverified', 'pending', 'verified', 'rejected')),
        kyc_type TEXT DEFAULT 'Aadhaar',
        kyc_id_masked TEXT DEFAULT 'XXXX-XXXX-8921',
        kyc_verified_at TEXT,
        created_at TEXT NOT NULL
    )
    """)

    # 2. Workers Profile Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS workers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL UNIQUE,
        cooperative_society_name TEXT NOT NULL,
        primary_skill TEXT NOT NULL,
        secondary_skills TEXT,
        experience_years INTEGER NOT NULL DEFAULT 1,
        hourly_rate REAL NOT NULL,
        bio TEXT,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        is_available INTEGER NOT NULL DEFAULT 1,
        jobs_completed INTEGER NOT NULL DEFAULT 0,
        avg_rating REAL NOT NULL DEFAULT 5.0,
        rating_count INTEGER NOT NULL DEFAULT 0,
        response_rate REAL NOT NULL DEFAULT 98.0,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )
    """)

    # 3. Certifications Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS certifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        worker_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        issuing_body TEXT NOT NULL,
        issue_date TEXT NOT NULL,
        certificate_number TEXT NOT NULL,
        is_verified INTEGER NOT NULL DEFAULT 1,
        document_url TEXT,
        FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
    )
    """)

    # 4. Tax and Commission Config Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS tax_config (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        cgst_rate REAL NOT NULL DEFAULT 0.0025,       -- 0.25%
        sgst_rate REAL NOT NULL DEFAULT 0.0025,       -- 0.25%
        igst_rate REAL NOT NULL DEFAULT 0.0050,       -- 0.50%
        worker_contribution_rate REAL NOT NULL DEFAULT 0.05, -- 5% Worker Skill Fund
        platform_fee_rate REAL NOT NULL DEFAULT 0.05,        -- 5% Non-profit Cooperative Platform Fee
        updated_at TEXT NOT NULL
    )
    """)

    # 5. Bookings Table (with Dual Independent Confirmation Lifecycle)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_code TEXT NOT NULL UNIQUE,
        customer_id INTEGER NOT NULL,
        worker_id INTEGER NOT NULL,
        service_type TEXT NOT NULL,
        scheduled_time TEXT NOT NULL,
        notes TEXT,
        base_amount REAL NOT NULL,
        tax_type TEXT NOT NULL,                    -- 'INTRA_STATE (CGST+SGST)' or 'INTER_STATE (IGST)'
        tax_rate REAL NOT NULL,
        tax_amount REAL NOT NULL,
        worker_fund_contribution REAL NOT NULL,    -- 5% for skill training & welfare
        platform_fee REAL NOT NULL,                -- 5%
        total_payable REAL NOT NULL,
        customer_state TEXT NOT NULL,
        worker_state TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN (
            'Requested',
            'Accepted',
            'In Progress',
            'Work Completed - Pending Customer Confirmation',
            'Completed',
            'Cancelled'
        )),
        work_confirmed_by_customer INTEGER NOT NULL DEFAULT 0,
        work_confirmed_at TEXT,
        payment_confirmed_by_worker INTEGER NOT NULL DEFAULT 0,
        payment_confirmed_at TEXT,
        cancel_reason TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (customer_id) REFERENCES users(id),
        FOREIGN KEY (worker_id) REFERENCES workers(id)
    )
    """)

    # 6. Ratings Table (Two-Way)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ratings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        from_user_id INTEGER NOT NULL,
        to_user_id INTEGER NOT NULL,
        rating_type TEXT NOT NULL CHECK(rating_type IN ('customer_to_worker', 'worker_to_customer')),
        score INTEGER NOT NULL CHECK(score BETWEEN 1 AND 5),
        aspect_score_safety INTEGER CHECK(aspect_score_safety BETWEEN 1 AND 5),
        aspect_score_punctuality INTEGER CHECK(aspect_score_punctuality BETWEEN 1 AND 5),
        comments TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (booking_id) REFERENCES bookings(id),
        FOREIGN KEY (from_user_id) REFERENCES users(id),
        FOREIGN KEY (to_user_id) REFERENCES users(id),
        UNIQUE(booking_id, rating_type)
    )
    """)

    # 7. Government Welfare Schemes Master Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS welfare_schemes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        ministry TEXT NOT NULL,
        target_group TEXT NOT NULL,
        min_age INTEGER NOT NULL,
        max_age INTEGER NOT NULL,
        max_monthly_income REAL,
        eligible_occupations TEXT,
        benefits_summary TEXT NOT NULL,
        premium_or_cost TEXT NOT NULL,
        official_portal_url TEXT NOT NULL,
        disclaimer TEXT NOT NULL
    )
    """)

    # 8. Worker Eligibility Profiles
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS worker_eligibility_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        worker_id INTEGER NOT NULL UNIQUE,
        age INTEGER NOT NULL,
        monthly_income REAL NOT NULL,
        occupation TEXT NOT NULL,
        state TEXT NOT NULL,
        has_epfo_esic INTEGER NOT NULL DEFAULT 0,
        existing_schemes_json TEXT,
        last_assessed_at TEXT NOT NULL,
        FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
    )
    """)

    # 9. Support & Callback Tickets Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS support_tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_number TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        role TEXT NOT NULL,
        issue_category TEXT NOT NULL,
        details TEXT,
        status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open', 'in_progress', 'resolved')),
        created_at TEXT NOT NULL
    )
    """)

    conn.commit()
    conn.close()


def seed_data(force=False):
    init_db()
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] > 0 and not force:
        conn.close()
        return

    if force:
        for tbl in ['ratings', 'bookings', 'certifications', 'worker_eligibility_profiles', 'workers', 'support_tickets', 'welfare_schemes', 'tax_config', 'users']:
            cursor.execute(f"DELETE FROM {tbl}")

    now_str = datetime.now().isoformat()

    # 1. Tax Config
    cursor.execute("""
    INSERT INTO tax_config (name, cgst_rate, sgst_rate, igst_rate, worker_contribution_rate, platform_fee_rate, updated_at)
    VALUES ('Standard Cooperative Tariff 2026', 0.0025, 0.0025, 0.0050, 0.05, 0.05, ?)
    """, (now_str,))

    # 2. Welfare Schemes (Real, publicly documented statutory schemes)
    schemes = [
        (
            "ESHRAM",
            "e-Shram: National Database of Unorganized Workers",
            "Ministry of Labour & Employment",
            "Unorganized / Gig Workers",
            16, 59, 25000.0,
            json.dumps(["Electrician", "Plumber", "Carpenter", "Domestic Helper", "Caregiver", "Painter", "Cleaner", "Driver", "Gardener", "Technician"]),
            "12-digit Universal Account Number (UAN), accidental insurance cover of Rs. 2 Lakh under PMSBY, priority social security benefits, DBT portability.",
            "Free of cost registration",
            "https://eshram.gov.in",
            "Informational assessment only. Enrollment must be completed directly via the official e-Shram portal or CSC centers. Kaam Konnect does not claim official processing authority."
        ),
        (
            "PMSYM",
            "Pradhan Mantri Shram Yogi Maan-dhan (PM-SYM)",
            "Ministry of Labour & Employment",
            "Unorganized Workers with monthly income <= Rs 15,000",
            18, 40, 15000.0,
            json.dumps(["Domestic Helper", "Gardener", "Cleaner", "Painter", "Carpenter", "Plumber", "Electrician", "Driver"]),
            "Guaranteed minimum pension of Rs. 3,000 per month after attaining 60 years of age. 50% contribution matched by Central Government.",
            "Monthly contribution Rs 55 to Rs 200 based on entry age (50% govt subsidy)",
            "https://maandhan.in",
            "Informational assessment only. Eligible workers must verify their bank account and enroll on the official Maandhan portal."
        ),
        (
            "PMSBY",
            "Pradhan Mantri Suraksha Bima Yojana (PMSBY)",
            "Ministry of Finance",
            "All Indian Citizens with savings bank account",
            18, 70, None,
            json.dumps(["All"]),
            "Accidental death and full permanent disability cover of Rs. 2,00,000; partial permanent disability cover of Rs. 1,00,000.",
            "Rs. 20 per annum auto-debited from bank account",
            "https://financialservices.gov.in",
            "Informational guidance. Available through scheduled commercial banks and post office savings accounts."
        ),
        (
            "PMJJBY",
            "Pradhan Mantri Jeevan Jyoti Bima Yojana (PMJJBY)",
            "Ministry of Finance",
            "All Indian Citizens with savings bank account",
            18, 50, None,
            json.dumps(["All"]),
            "Renewable term life insurance cover of Rs. 2,00,000 in case of death due to any cause.",
            "Rs. 436 per annum auto-debited from bank account",
            "https://financialservices.gov.in",
            "Informational guidance. Available through your linked bank branch."
        ),
        (
            "PMJAY",
            "Ayushman Bharat - Pradhan Mantri Jan Arogya Yojana (PM-JAY)",
            "National Health Authority / MoHFW",
            "Vulnerable and low-income occupational gig families",
            18, 75, 20000.0,
            json.dumps(["Domestic Helper", "Cleaner", "Gardener", "Driver"]),
            "Secondary and tertiary cashless hospitalization cover up to Rs. 5,00,000 per family per year at empaneled public & private hospitals across India.",
            "100% Fully subsidized by Government",
            "https://pmjay.gov.in",
            "Check Aadhaar / Ration card linkage on mera.pmjay.gov.in or nearest Ayushman Mitra kiosk."
        ),
        (
            "BOCW_BOARD",
            "Building & Other Construction Workers (BOCW) Welfare Schemes",
            "State Labour Welfare Boards (Delhi / Haryana / UP)",
            "Construction, Electrical, Plumbing, Painting, Carpentry Workers",
            18, 60, 30000.0,
            json.dumps(["Electrician", "Plumber", "Carpenter", "Painter", "Technician"]),
            "Scholarships for children, tool kit subsidies up to Rs. 10,000, maternity assistance, death and funeral grants, housing loan interest subsidy.",
            "Nominal Rs. 20 - 50 annual registration fee with State Labour Board",
            "https://labour.gov.in",
            "Subject to minimum 90 days engagement in construction/maintenance trades verified by Cooperative Society."
        )
    ]

    cursor.executemany("""
    INSERT INTO welfare_schemes (code, name, ministry, target_group, min_age, max_age, max_monthly_income, eligible_occupations, benefits_summary, premium_or_cost, official_portal_url, disclaimer)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, schemes)

    # 3. Users: Admin, Customers, Workers
    users_data = [
        ("admin", "Shri S. K. Awasthi", "+919810011223", "admin@ncct.coop.in", "Delhi", "New Delhi", "NCCT HQ, 3 Siri Institutional Area, August Kranti Marg", "verified", "UIDAI", "XXXX-XXXX-9901"),
        ("customer", "Priya Sharma", "+919876543210", "priya.sharma@example.com", "Delhi", "South Delhi", "B-42, Saket Residential Complex, Saket", "verified", "Aadhaar", "XXXX-XXXX-4512"),
        ("customer", "Anand Verma", "+919811223344", "anand.verma@example.com", "Haryana", "Gurugram", "Flat 704, Palm Grove, DLF Phase 5", "verified", "Aadhaar", "XXXX-XXXX-7833"),
        ("customer", "Meera Sen", "+919822334455", "meera.sen@example.com", "Uttar Pradesh", "Noida", "Tower C-12, Sector 62", "verified", "Aadhaar", "XXXX-XXXX-1994"),
        ("worker", "Ramesh Kumar", "+919818822331", "ramesh.electrician@coop.in", "Delhi", "South Delhi", "Chirag Dilli Village, Near Metro", "verified", "Aadhaar", "XXXX-XXXX-1122"),
        ("worker", "Sunita Devi", "+919818822332", "sunita.domestic@coop.in", "Delhi", "South Delhi", "Kotla Mubarakpur, South Ext", "verified", "Aadhaar", "XXXX-XXXX-3344"),
        ("worker", "Manoj Chauhan", "+919818822333", "manoj.plumber@coop.in", "Haryana", "Gurugram", "Saraswati Vihar, Chakkarpur, MG Road", "verified", "Aadhaar", "XXXX-XXXX-5566"),
        ("worker", "Rajesh Sharma", "+919818822334", "rajesh.carpenter@coop.in", "Delhi", "South Delhi", "Malviya Nagar Corner", "verified", "Aadhaar", "XXXX-XXXX-7788"),
        ("worker", "Aarti Rawat", "+919818822335", "aarti.caregiver@coop.in", "Delhi", "South West Delhi", "Sector 7, Dwarka", "verified", "Aadhaar", "XXXX-XXXX-9900"),
        ("worker", "Mohammad Imran", "+919818822336", "imran.painter@coop.in", "Uttar Pradesh", "Noida", "Barola Village, Sector 49", "verified", "Aadhaar", "XXXX-XXXX-2233"),
        ("worker", "Kavita Bai", "+919818822337", "kavita.cleaner@coop.in", "Haryana", "Gurugram", "Sikanderpur Ghosi", "verified", "Aadhaar", "XXXX-XXXX-4455"),
        ("worker", "Deepak Verma", "+919818822338", "deepak.ac@coop.in", "Delhi", "South Delhi", "Lajpat Nagar Part 4", "verified", "Aadhaar", "XXXX-XXXX-6677"),
        ("worker", "Santosh Yadav", "+919818822339", "santosh.driver@coop.in", "Delhi", "South West Delhi", "Palam Colony, Mahavir Enclave", "verified", "Aadhaar", "XXXX-XXXX-8899"),
        ("worker", "Hari Ram", "+919818822340", "hariram.gardener@coop.in", "Delhi", "South Delhi", "Hauz Khas Enclave Extension", "verified", "Aadhaar", "XXXX-XXXX-1357")
    ]

    user_ids = {}
    for role, name, phone, email, state, city, address, kyc_status, kyc_type, kyc_id_masked in users_data:
        cursor.execute("""
        INSERT INTO users (role, name, phone, email, state, city, address, kyc_status, kyc_type, kyc_id_masked, kyc_verified_at, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (role, name, phone, email, state, city, address, kyc_status, kyc_type, kyc_id_masked, now_str, now_str))
        user_ids[email] = cursor.lastrowid

    # 4. Workers details
    workers_meta = [
        (
            "ramesh.electrician@coop.in",
            "Dakshin Dilli Shramik Swavalamban Sahakari Samiti",
            "Electrician",
            "Appliance Wiring, Inverter Maintenance, MCB Replacement",
            9, 380.0,
            "Licensed Grade-A wireman with 9 years of experience in residential circuits and safety inspections. Certified by NCCT & NSDC.",
            28.5355, 77.2185, 1, 142, 4.9, 87, 99.0
        ),
        (
            "sunita.domestic@coop.in",
            "Pragati Mahila Griha Seva Sahakari Samiti",
            "Domestic Helper",
            "Housekeeping, Meal Preparation, Utensil Sanitization",
            7, 300.0,
            "Experienced domestic specialist trained in modern kitchen hygiene and safe housekeeping practices. Police verified & Aadhaar authenticated.",
            28.5682, 77.2215, 1, 215, 4.8, 140, 97.5
        ),
        (
            "manoj.plumber@coop.in",
            "Gurugram Labour Welfare Cooperative Society Ltd.",
            "Plumber",
            "Leakage Detection, Sanitary Fitting, Water Motor Installation",
            6, 420.0,
            "Specialized in high-pressure plumbing, bathroom fitting upgrades, and zero-leakage piping. Fast 30-minute arrival in DLF/Sushant Lok.",
            28.4795, 77.0870, 1, 98, 4.85, 63, 96.0
        ),
        (
            "rajesh.carpenter@coop.in",
            "Dakshin Dilli Shramik Swavalamban Sahakari Samiti",
            "Carpenter",
            "Modular Furniture Assembly, Door Lock Fitting, Polish",
            12, 450.0,
            "Master artisan in woodwork restoration, hinge adjustments, and modular furniture setup. Cooperative society committee member.",
            28.5284, 77.2065, 1, 180, 4.92, 112, 98.5
        ),
        (
            "aarti.caregiver@coop.in",
            "Sewa Bharti Parivaar Seva Sahakari Sangh",
            "Caregiver",
            "Elderly Mobility Assistance, Vitals Monitoring, Post-Surgery Care",
            8, 500.0,
            "Certified geriatric care assistant with hospital training in patient mobility, basic first-aid, and medication administration.",
            28.5823, 77.0500, 1, 76, 4.95, 52, 100.0
        ),
        (
            "imran.painter@coop.in",
            "Noida Vikas Labour Cooperative Federation",
            "Painter",
            "Waterproofing, Wall Stencils, Interior Emulsion",
            10, 390.0,
            "Expert in damp-proofing, wall leveling, Asian Paints color matching, and clean surface preparation.",
            28.5670, 77.3650, 1, 114, 4.78, 71, 95.0
        ),
        (
            "kavita.cleaner@coop.in",
            "Gurugram Labour Welfare Cooperative Society Ltd.",
            "Cleaner",
            "Deep Bathroom Sanitization, Kitchen Degreasing, Balcony Wash",
            5, 320.0,
            "Trained in eco-friendly chemical sanitation, steam cleaning, and dust eradication. Cooperative verified identity.",
            28.4820, 77.0980, 1, 84, 4.82, 49, 97.0
        ),
        (
            "deepak.ac@coop.in",
            "Dakshin Dilli Shramik Swavalamban Sahakari Samiti",
            "Technician",
            "AC Servicing, Refrigerator Gas Charging, Washing Machine Repair",
            8, 480.0,
            "Specialist refrigeration and HVAC technician. Certified by National Council for Cooperative Training (NCCT).",
            28.5665, 77.2435, 1, 131, 4.88, 85, 99.0
        ),
        (
            "santosh.driver@coop.in",
            "Indraprastha Sarathi Sahakari Samiti",
            "Driver",
            "City Driving, Automatic Transmission, Outstation Trips",
            11, 400.0,
            "Punctual commercial badge driver with unblemished safety track record. High customer ratings for courteous behavior.",
            28.5910, 77.0720, 1, 160, 4.9, 104, 98.0
        ),
        (
            "hariram.gardener@coop.in",
            "Dakshin Dilli Shramik Swavalamban Sahakari Samiti",
            "Gardener",
            "Lawn Trimming, Organic Pest Control, Bonsai Pruning",
            14, 350.0,
            "Experienced horticulturist specializing in terrace gardens, ornamental plants, and soil rejuvenation.",
            28.5490, 77.2020, 1, 92, 4.86, 58, 96.5
        )
    ]

    worker_ids = {}
    for email, coop_name, skill, sec_skills, exp, rate, bio, lat, lng, is_avail, jobs, rating, rating_count, resp_rate in workers_meta:
        uid = user_ids[email]
        cursor.execute("""
        INSERT INTO workers (user_id, cooperative_society_name, primary_skill, secondary_skills, experience_years, hourly_rate, bio, latitude, longitude, is_available, jobs_completed, avg_rating, rating_count, response_rate)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (uid, coop_name, skill, sec_skills, exp, rate, bio, lat, lng, is_avail, jobs, rating, rating_count, resp_rate))
        worker_ids[email] = cursor.lastrowid

    # 5. Certifications
    certs_data = [
        (worker_ids["ramesh.electrician@coop.in"], "Certified Domestic Electrician (Level 4)", "National Council for Cooperative Training (NCCT)", "2022-04-15", "NCCT-ELE-2022-8819", 1),
        (worker_ids["ramesh.electrician@coop.in"], "Electrical Safety & Fire Prevention Certificate", "Delhi Labour Welfare Board", "2023-08-10", "DLWB-SAF-9921", 1),
        (worker_ids["sunita.domestic@coop.in"], "Home Management & Sanitation Skills", "NCCT Rural Cooperative Academy", "2021-11-20", "NCCT-HMS-2021-3412", 1),
        (worker_ids["sunita.domestic@coop.in"], "e-Shram Registered Shramik Card", "Ministry of Labour & Employment", "2021-09-05", "UAN-8891-2309-1122", 1),
        (worker_ids["manoj.plumber@coop.in"], "Advanced Plumbing & Pipefitting License", "National Skill Development Corporation (NSDC)", "2020-03-12", "NSDC-PLM-77123", 1),
        (worker_ids["rajesh.carpenter@coop.in"], "Master Carpentry & Architectural Woodwork", "Cooperative Federation of India", "2019-07-22", "CFI-CARP-2019-102", 1),
        (worker_ids["aarti.caregiver@coop.in"], "Certified Geriatric & Palliative Care Assistant", "Red Cross Society & NCCT Partnered", "2021-02-18", "RCS-GCA-2021-440", 1),
        (worker_ids["deepak.ac@coop.in"], "HVAC & Commercial Refrigeration Specialist", "NCCT Technical Skill Center", "2020-10-14", "NCCT-HVAC-2020-761", 1)
    ]

    cursor.executemany("""
    INSERT INTO certifications (worker_id, title, issuing_body, issue_date, certificate_number, is_verified)
    VALUES (?, ?, ?, ?, ?, ?)
    """, certs_data)

    # 6. Worker Welfare Profiles
    scheme_profiles = [
        (worker_ids["ramesh.electrician@coop.in"], 34, 18500.0, "Electrician", "Delhi", 0, json.dumps(["ESHRAM"])),
        (worker_ids["sunita.domestic@coop.in"], 38, 12000.0, "Domestic Helper", "Delhi", 0, json.dumps(["ESHRAM", "PMSBY"])),
        (worker_ids["manoj.plumber@coop.in"], 29, 21000.0, "Plumber", "Haryana", 0, json.dumps(["BOCW_BOARD"])),
        (worker_ids["kavita.cleaner@coop.in"], 42, 11500.0, "Cleaner", "Haryana", 0, json.dumps([])),
        (worker_ids["hariram.gardener@coop.in"], 48, 14000.0, "Gardener", "Delhi", 0, json.dumps(["PMSBY"]))
    ]

    for wid, age, inc, occ, st, epf, ex_json in scheme_profiles:
        cursor.execute("""
        INSERT INTO worker_eligibility_profiles (worker_id, age, monthly_income, occupation, state, has_epfo_esic, existing_schemes_json, last_assessed_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (wid, age, inc, occ, st, epf, ex_json, now_str))

    # 7. Seed Sample Bookings
    cust_priya_id = user_ids["priya.sharma@example.com"]
    cust_anand_id = user_ids["anand.verma@example.com"]
    w_ramesh_id = worker_ids["ramesh.electrician@coop.in"]
    w_sunita_id = worker_ids["sunita.domestic@coop.in"]

    sample_bookings = [
        (
            "KK-2026-DEL-101",
            cust_priya_id,
            w_ramesh_id,
            "Electrician - Switchboard & Circuit Diagnostic",
            (datetime.now() - timedelta(days=2)).strftime("%Y-%m-%d 10:00"),
            "Main circuit breaker tripping intermittently in hall.",
            760.0,
            "INTRA_STATE (CGST 0.25% + SGST 0.25%)",
            0.0050,
            3.80,
            38.00,
            38.00,
            763.80,
            "Delhi",
            "Delhi",
            "Completed",
            1, (datetime.now() - timedelta(days=2, hours=2)).isoformat(),
            1, (datetime.now() - timedelta(days=2, hours=1, minutes=55)).isoformat(),
            None,
            (datetime.now() - timedelta(days=3)).isoformat(),
            (datetime.now() - timedelta(days=2)).isoformat()
        ),
        (
            "KK-2026-INT-202",
            cust_anand_id,
            w_ramesh_id,
            "Electrician - Smart Home Inverter Cabling",
            (datetime.now() + timedelta(hours=3)).strftime("%Y-%m-%d 15:00"),
            "Installing 2.5 KVA pure sinewave inverter wiring in Gurgaon DLF.",
            1140.0,
            "INTER_STATE (IGST 0.50%)",
            0.0050,
            5.70,
            57.00,
            57.00,
            1145.70,
            "Haryana",
            "Delhi",
            "In Progress",
            0, None,
            0, None,
            None,
            (datetime.now() - timedelta(days=1)).isoformat(),
            now_str
        ),
        (
            "KK-2026-DEL-303",
            cust_priya_id,
            w_sunita_id,
            "Domestic Helper - Deep Housekeeping & Sanitization",
            (datetime.now() - timedelta(hours=5)).strftime("%Y-%m-%d 09:00"),
            "Kitchen deep clean and window sill scrubbing.",
            900.0,
            "INTRA_STATE (CGST 0.25% + SGST 0.25%)",
            0.0050,
            4.50,
            45.00,
            45.00,
            904.50,
            "Delhi",
            "Delhi",
            "Work Completed - Pending Customer Confirmation",
            0, None,
            1, (datetime.now() - timedelta(hours=1)).isoformat(),
            None,
            (datetime.now() - timedelta(days=1)).isoformat(),
            now_str
        )
    ]

    for b in sample_bookings:
        cursor.execute("""
        INSERT INTO bookings (
            booking_code, customer_id, worker_id, service_type, scheduled_time, notes,
            base_amount, tax_type, tax_rate, tax_amount, worker_fund_contribution, platform_fee, total_payable,
            customer_state, worker_state, status,
            work_confirmed_by_customer, work_confirmed_at,
            payment_confirmed_by_worker, payment_confirmed_at,
            cancel_reason, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, b)
        booking_id = cursor.lastrowid

        if b[15] == "Completed":
            cursor.execute("""
            INSERT INTO ratings (booking_id, from_user_id, to_user_id, rating_type, score, aspect_score_safety, aspect_score_punctuality, comments, created_at)
            VALUES (?, ?, ?, 'customer_to_worker', 5, 5, 5, 'Extremely punctual, verified identity, resolved the MCB tripping problem safely with zero mess.', ?)
            """, (booking_id, cust_priya_id, user_ids["ramesh.electrician@coop.in"], now_str))

            cursor.execute("""
            INSERT INTO ratings (booking_id, from_user_id, to_user_id, rating_type, score, aspect_score_safety, aspect_score_punctuality, comments, created_at)
            VALUES (?, ?, ?, 'worker_to_customer', 5, 5, 5, 'Respectful household, clean workspace, prompt direct UPI payment as soon as work finished.', ?)
            """, (booking_id, user_ids["ramesh.electrician@coop.in"], cust_priya_id, now_str))

    cursor.execute("""
    INSERT INTO support_tickets (ticket_number, name, phone, role, issue_category, details, status, created_at)
    VALUES ('TCK-2026-8801', 'Sunita Devi', '+919818822332', 'worker', 'e-KYC Assistance', 'Needed assistance updating mobile number OTP for Aadhaar verification.', 'resolved', ?)
    """, (now_str,))

    conn.commit()
    conn.close()
    print("Kaam Konnect database successfully initialized and seeded.")


if __name__ == "__main__":
    seed_data(force=True)
